'use strict';
// Northline TV for Windows and Mac: your own Xtream TV services, a guide, and live TV.

const $ = (id) => document.getElementById(id);
const store = {
  get(k, d) { try { const v = localStorage.getItem('nl.' + k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem('nl.' + k, JSON.stringify(v)); } catch (_) {} },
};

const state = {
  services: store.get('services', []),
  active: store.get('active', 0),
  cats: [], streams: [], byCat: new Map(),
  group: store.get('group', '__all'),
  query: '',
  shown: [], rendered: 0,
  playing: null,
  epg: new Map(),
  format: store.get('format', 'ts'),
};

// ---------------- TV service (Xtream) ----------------

function baseOf(server) {
  let s = String(server || '').trim().replace(/\/+$/, '');
  if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
  return s;
}
const svc = () => state.services[state.active];
function api(s, action, extra = '') {
  const u = `${baseOf(s.server)}/player_api.php?username=${encodeURIComponent(s.user)}&password=${encodeURIComponent(s.pass)}` + (action ? `&action=${action}` : '') + extra;
  return fetch(u, { cache: 'no-store' }).then((r) => { if (!r.ok) throw new Error('The server answered ' + r.status); return r.json(); });
}
function streamUrl(s, id, fmt) { return `${baseOf(s.server)}/live/${encodeURIComponent(s.user)}/${encodeURIComponent(s.pass)}/${id}.${fmt}`; }
const favKey = () => 'favs.' + (svc() ? baseOf(svc().server) + '|' + svc().user : '');
const favs = () => new Set(store.get(favKey(), []));

// ---------------- sign in ----------------

let addingExtra = false;
function showSignin(extra) {
  addingExtra = !!extra;
  $('signin').hidden = false; $('main').hidden = true;
  $('signinCancel').hidden = !extra;
  $('signinError').hidden = true;
  $('user').value = ''; $('pass').value = ''; $('svcName').value = '';
  setTimeout(() => $('user').focus(), 50);
}
document.querySelectorAll('input[name=server]').forEach((r) => r.addEventListener('change', () => {
  $('customServer').hidden = document.querySelector('input[name=server]:checked').value !== 'custom';
  if (!$('customServer').hidden) $('customServer').focus();
}));
$('signinCancel').addEventListener('click', () => { $('signin').hidden = true; $('main').hidden = false; });
$('signinForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const pick = document.querySelector('input[name=server]:checked').value;
  const server = pick === 'custom' ? $('customServer').value.trim() : pick;
  const s = { server, user: $('user').value.trim(), pass: $('pass').value, name: $('svcName').value.trim() };
  const err = $('signinError');
  if (!s.server || !s.user || !s.pass) { err.textContent = 'Fill in the server, username and password.'; err.hidden = false; return; }
  $('signinBtn').disabled = true; $('signinBtn').textContent = 'Checking…'; err.hidden = true;
  try {
    const info = await api(s, '');
    if (!info || !info.user_info || String(info.user_info.auth) === '0') throw new Error('The server rejected this username or password.');
    if (!s.name) s.name = (s.server.split(/[.:]/)[0] || 'TV').slice(0, 14);
    const same = state.services.findIndex((x) => baseOf(x.server).toLowerCase() === baseOf(s.server).toLowerCase() && x.user === s.user);
    if (same >= 0) state.services[same] = s; else state.services.push(s);
    state.active = same >= 0 ? same : state.services.length - 1;
    store.set('services', state.services); store.set('active', state.active);
    $('signin').hidden = true;
    await openService();
  } catch (ex) {
    err.textContent = "Couldn't sign in: " + (ex.message === 'Failed to fetch' ? "the server didn't answer. Check the server name and your internet." : ex.message);
    err.hidden = false;
  } finally { $('signinBtn').disabled = false; $('signinBtn').textContent = 'Sign in'; }
});

// ---------------- loading a service ----------------

function fillServices() {
  const sel = $('svcSelect'); sel.innerHTML = '';
  state.services.forEach((s, i) => { const o = document.createElement('option'); o.value = i; o.textContent = s.name || s.server; sel.appendChild(o); });
  sel.value = state.active;
}
$('svcSelect').addEventListener('change', (e) => { state.active = +e.target.value; store.set('active', state.active); state.group = '__all'; openService(); });
$('addSvc').addEventListener('click', () => showSignin(true));

async function openService() {
  const s = svc(); if (!s) return showSignin(false);
  $('main').hidden = false; fillServices();
  if (window.vodReset) window.vodReset();
  $('list').innerHTML = '<div class="emptyMsg">Loading channels…</div>';
  $('groups').innerHTML = ''; state.epg.clear();
  try {
    const [info, cats, streams] = await Promise.all([api(s, ''), api(s, 'get_live_categories'), api(s, 'get_live_streams')]);
    const exp = info && info.user_info && +info.user_info.exp_date;
    if (exp) {
      const days = Math.ceil((exp * 1000 - Date.now()) / 86400000);
      $('expiry').textContent = 'Expires ' + new Date(exp * 1000).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) + ' · ' + days + ' days left';
      $('expiry').className = 'small ' + (days <= 7 ? 'error' : 'dim');
    } else $('expiry').textContent = '';
    state.cats = Array.isArray(cats) ? cats : [];
    state.streams = (Array.isArray(streams) ? streams : []).map((x, i) => ({
      id: String(x.stream_id), num: +x.num || i + 1, name: String(x.name || '').trim(), icon: x.stream_icon || '', cat: String(x.category_id || ''),
    }));
    state.byCat = new Map();
    for (const x of state.streams) { if (!state.byCat.has(x.cat)) state.byCat.set(x.cat, []); state.byCat.get(x.cat).push(x); }
    drawGroups();
    showGroup(state.group);
    const last = store.get('last.' + favKey(), null);
    const ch = last && state.streams.find((x) => x.id === last);
    if (ch) select(ch, true);
  } catch (ex) {
    $('list').innerHTML = '';
    const m = document.createElement('div'); m.className = 'emptyMsg';
    m.textContent = "Couldn't load your channels: " + ex.message + '. Check your internet, or pick another service.';
    $('list').appendChild(m);
  }
}

// ---------------- groups ----------------

function drawGroups() {
  const g = $('groups'); g.innerHTML = '';
  const add = (id, label) => {
    const b = document.createElement('button'); b.textContent = label; b.dataset.id = id; b.title = label;
    b.addEventListener('click', () => { $('search').value = ''; state.query = ''; showGroup(id); });
    g.appendChild(b);
  };
  add('__fav', '★ Favorites'); add('__all', 'All channels');
  for (const c of state.cats) if (state.byCat.has(String(c.category_id))) add(String(c.category_id), String(c.category_name || '').trim());
}
function markGroup() { document.querySelectorAll('#groups button').forEach((b) => b.classList.toggle('on', b.dataset.id === state.group && !state.query)); }

function showGroup(id) {
  if (id !== '__fav' && id !== '__all' && !state.byCat.has(id)) id = '__all';
  state.group = id; store.set('group', id);
  const f = favs();
  state.shown = id === '__fav' ? state.streams.filter((x) => f.has(x.id)) : id === '__all' ? state.streams : state.byCat.get(id);
  markGroup(); drawList(id === '__fav' && !state.shown.length ? 'No favorites yet. Click ☆ on a channel to add it.' : 'No channels here.');
}

let searchTimer = 0;
$('search').addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    const q = $('search').value.trim().toLowerCase(); state.query = q;
    if (!q) return showGroup(state.group);
    const words = q.split(/\s+/);
    state.shown = state.streams.filter((x) => { const n = x.name.toLowerCase(); return words.every((w) => n.includes(w)); }).slice(0, 2000);
    markGroup(); drawList('No channels match “' + $('search').value.trim() + '”.');
  }, 200);
});

// ---------------- the guide list (drawn as you scroll) ----------------

const SLOT = 30 * 60000, WINDOW = 4 * SLOT;
let winStart = 0;
function drawTimeline() {
  const now = Date.now(); winStart = now - (now % SLOT);
  const t = $('timeline'); t.innerHTML = '';
  const day = document.createElement('span'); day.className = 'day';
  day.textContent = new Date().toLocaleString(undefined, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  t.appendChild(day);
  for (let i = 0; i < 4; i++) { const s = document.createElement('span'); s.className = 'slot'; s.textContent = new Date(winStart + i * SLOT).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }); t.appendChild(s); }
}

const io = new IntersectionObserver((entries) => {
  for (const e of entries) if (e.isIntersecting) { io.unobserve(e.target); loadEpg(e.target._ch, e.target); }
}, { root: $('list'), rootMargin: '200px' });

function drawList(emptyText) {
  drawTimeline();
  const list = $('list'); list.innerHTML = ''; list.scrollTop = 0; state.rendered = 0;
  if (!state.shown.length) { const m = document.createElement('div'); m.className = 'emptyMsg'; m.textContent = emptyText; list.appendChild(m); return; }
  moreRows();
}
function moreRows() {
  const list = $('list'); const f = favs();
  const end = Math.min(state.shown.length, state.rendered + 120);
  for (let i = state.rendered; i < end; i++) list.appendChild(row(state.shown[i], f.has(state.shown[i].id)));
  state.rendered = end;
}
$('list').addEventListener('scroll', () => {
  const l = $('list'); if (l.scrollTop + l.clientHeight > l.scrollHeight - 600 && state.rendered < state.shown.length) moreRows();
});

function row(ch, isFav) {
  const r = document.createElement('div'); r.className = 'ch'; r.tabIndex = 0; r.setAttribute('role', 'listitem'); r._ch = ch; r.dataset.id = ch.id;
  if (state.playing && state.playing.id === ch.id) r.classList.add('on');
  const n = document.createElement('div'); n.className = 'name';
  const num = document.createElement('span'); num.className = 'num'; num.textContent = ch.num;
  n.appendChild(num);
  if (ch.icon) { const im = document.createElement('img'); im.className = 'icon'; im.loading = 'lazy'; im.alt = ''; im.src = ch.icon; im.onerror = () => im.remove(); n.appendChild(im); }
  const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = ch.name; n.appendChild(nm);
  const st = document.createElement('button'); st.className = 'star' + (isFav ? ' on' : ''); st.textContent = isFav ? '★' : '☆';
  st.title = isFav ? 'Remove from favorites' : 'Add to favorites'; st.setAttribute('aria-label', st.title);
  st.addEventListener('click', (e) => { e.stopPropagation(); toggleFav(ch, st); });
  n.appendChild(st);
  const p = document.createElement('div'); p.className = 'progs';
  drawProgs(p, state.epg.get(ch.id));
  r.appendChild(n); r.appendChild(p);
  r.addEventListener('click', () => select(ch));
  r.addEventListener('dblclick', () => { select(ch); fullscreen(); });
  io.observe(r);
  return r;
}

function toggleFav(ch, btn) {
  const f = favs(); const on = !f.has(ch.id);
  if (on) f.add(ch.id); else f.delete(ch.id);
  store.set(favKey(), [...f]);
  btn.classList.toggle('on', on); btn.textContent = on ? '★' : '☆';
  if (state.group === '__fav' && !state.query) showGroup('__fav');
}

function b64(s) { try { return decodeURIComponent(escape(atob(s))); } catch (_) { return s || ''; } }
async function loadEpg(ch, r) {
  if (state.epg.has(ch.id)) return;
  state.epg.set(ch.id, null);
  try {
    const o = await api(svc(), 'get_short_epg', `&stream_id=${encodeURIComponent(ch.id)}&limit=6`);
    const l = (o.epg_listings || []).map((e) => ({ start: +e.start_timestamp * 1000, stop: +(e.stop_timestamp || e.end_timestamp) * 1000, title: b64(e.title).trim(), desc: b64(e.description).trim() }))
      .filter((e) => e.start && e.stop > e.start).sort((a, b) => a.start - b.start);
    state.epg.set(ch.id, l);
    const p = r.querySelector('.progs'); if (p) drawProgs(p, l);
    if (state.playing && state.playing.id === ch.id) showInfo(ch);
  } catch (_) { state.epg.set(ch.id, []); }
}

function drawProgs(p, l) {
  p.innerHTML = '';
  const end = winStart + WINDOW;
  const inWin = (l || []).filter((e) => e.stop > winStart && e.start < end);
  if (!inWin.length) {
    const d = document.createElement('div'); d.className = 'prog empty'; d.style.left = '0'; d.style.right = '0';
    d.textContent = l ? 'No information' : ''; p.appendChild(d);
  }
  for (const e of inWin) {
    const s = Math.max(e.start, winStart), t = Math.min(e.stop, end);
    const d = document.createElement('div'); d.className = 'prog';
    d.style.left = ((s - winStart) / WINDOW * 100) + '%'; d.style.width = ((t - s) / WINDOW * 100) + '%';
    d.textContent = e.title || 'No title';
    d.title = e.title + '\n' + hhmm(e.start) + ' – ' + hhmm(e.stop) + (e.desc ? '\n\n' + e.desc : '');
    p.appendChild(d);
  }
  const nl = document.createElement('div'); nl.className = 'nowline'; nl.style.left = ((Date.now() - winStart) / WINDOW * 100) + '%'; p.appendChild(nl);
}
const hhmm = (t) => new Date(t).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

// ---------------- the player ----------------

const video = $('video');
let mp = null, hls = null, tries = 0, lastTime = -1, stuckSince = 0;

function stopPlayer() {
  try { if (mp) { mp.pause(); mp.unload(); mp.detachMediaElement(); mp.destroy(); } } catch (_) {}
  try { if (hls) hls.destroy(); } catch (_) {}
  mp = null; hls = null; video.removeAttribute('src'); try { video.load(); } catch (_) {}
}
function msg(t) { const m = $('playerMsg'); m.textContent = t || ''; m.hidden = !t; }

function select(ch, quiet) {
  state.playing = ch; tries = 0;
  store.set('last.' + favKey(), ch.id);
  document.querySelectorAll('.ch.on').forEach((x) => x.classList.remove('on'));
  const r = document.querySelector(`.ch[data-id="${CSS.escape(ch.id)}"]`); if (r) { r.classList.add('on'); if (!quiet) r.focus({ preventScroll: true }); }
  showInfo(ch);
  start(ch, state.format);
}

function start(ch, fmt) {
  stopPlayer(); msg('Loading ' + ch.name + '…');
  lastTime = -1; stuckSince = 0;
  const url = streamUrl(svc(), ch.id, fmt);
  if (fmt === 'ts' && window.mpegts && mpegts.getFeatureList().mseLivePlayback) {
    mp = mpegts.createPlayer({ type: 'mpegts', isLive: true, url }, { enableWorker: true, enableStashBuffer: true, stashInitialSize: 384 * 1024, liveBufferLatencyChasing: false, lazyLoad: false });
    mp.attachMediaElement(video); mp.load();
    mp.on(mpegts.Events.ERROR, () => failed(ch, fmt));
    video.play().catch(() => {});
  } else if (window.Hls && Hls.isSupported()) {
    hls = new Hls({ lowLatencyMode: false, backBufferLength: 60 });
    hls.on(Hls.Events.ERROR, (_, d) => { if (d.fatal) failed(ch, fmt); });
    hls.loadSource(streamUrl(svc(), ch.id, 'm3u8')); hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, () => video.play().catch(() => {}));
  } else { video.src = url; video.play().catch(() => {}); }
}

// a channel that won't load tries again, then the other stream format, before giving up
function failed(ch, fmt) {
  if (!state.playing || state.playing.id !== ch.id) return;
  tries++;
  const other = fmt === 'ts' ? 'm3u8' : 'ts';
  if (tries === 1) { msg('Reconnecting…'); setTimeout(() => state.playing === ch && start(ch, fmt), 1500); }
  else if (tries === 2) { msg('Trying the other stream format…'); start(ch, other); }
  else if (tries <= 4) { msg('Reconnecting…'); setTimeout(() => state.playing === ch && start(ch, tries % 2 ? fmt : other), 4000); }
  else msg("Can't play " + ch.name + ' right now. Try another channel, or another service.');
}

video.addEventListener('playing', () => { msg(''); tries = 0; });
video.addEventListener('waiting', () => { if (!video.paused) stuckSince = stuckSince || Date.now(); });
// every 3 seconds: is the picture moving? stuck for 12 s while playing = reconnect (like the Fire Stick app)
setInterval(() => {
  const ch = state.playing; if (!ch || video.paused || document.hidden && !document.pictureInPictureElement) return;
  const t = video.currentTime;
  if (t === lastTime) { stuckSince = stuckSince || Date.now(); if (Date.now() - stuckSince > 12000) { stuckSince = 0; msg('Reconnecting…'); start(ch, state.format); } }
  else { stuckSince = 0; }
  lastTime = t;
}, 3000);

function showInfo(ch) {
  const l = state.epg.get(ch.id) || []; const now = Date.now();
  const cur = l.find((e) => e.start <= now && e.stop > now);
  const next = l.find((e) => e.start > now);
  $('infoCh').textContent = ch.num + '  ' + ch.name;
  $('infoTitle').textContent = cur ? cur.title : ch.name;
  $('infoTime').textContent = cur ? hhmm(cur.start) + ' – ' + hhmm(cur.stop) + ' · ' + Math.max(1, Math.round((cur.stop - now) / 60000)) + ' min left' + (next ? '   ·   Next: ' + next.title + ' ' + hhmm(next.start) : '') : 'No program information';
  $('infoDesc').textContent = cur ? cur.desc : '';
  document.title = ch.name + ' · Northline TV';
}

function fullscreen() { const b = $('playerBox'); if (document.fullscreenElement) document.exitFullscreen(); else b.requestFullscreen().catch(() => {}); }
function togglePlay() { if (video.paused) video.play().catch(() => {}); else video.pause(); }
function toggleMute() { video.muted = !video.muted; }
async function pip() { try { if (document.pictureInPictureElement) await document.exitPictureInPicture(); else await video.requestPictureInPicture(); } catch (_) {} }
function seek(s) {
  const b = video.buffered; if (!b.length) return;
  video.currentTime = Math.min(b.end(b.length - 1) - 0.5, Math.max(b.start(0), video.currentTime + s));
}

$('playPause').addEventListener('click', togglePlay);
$('muteBtn').addEventListener('click', toggleMute);
$('fsBtn').addEventListener('click', fullscreen);
$('pipBtn').addEventListener('click', pip);
$('volume').addEventListener('input', (e) => { video.volume = +e.target.value; video.muted = false; store.set('volume', video.volume); });
video.volume = store.get('volume', 1); $('volume').value = video.volume;
video.addEventListener('dblclick', fullscreen);
video.addEventListener('click', togglePlay);
video.addEventListener('play', () => { $('playPause').textContent = '❚❚'; });
video.addEventListener('pause', () => { $('playPause').textContent = '▶'; });
video.addEventListener('volumechange', () => { $('muteBtn').textContent = video.muted ? '🔇' : '🔊'; });

function step(d) {
  const list = state.shown; if (!list.length) return;
  const i = state.playing ? list.findIndex((x) => x.id === state.playing.id) : -1;
  const n = list[(i + d + list.length) % list.length];
  const idx = list.indexOf(n);
  while (state.rendered <= idx) moreRows();
  select(n);
  const r = document.querySelector(`.ch[data-id="${CSS.escape(n.id)}"]`); if (r) r.scrollIntoView({ block: 'nearest' });
}

document.addEventListener('keydown', (e) => {
  const typing = /^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement && document.activeElement.tagName) && document.activeElement.type !== 'range' && document.activeElement.type !== 'radio';
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') { e.preventDefault(); const sb = window.nlMode && window.nlMode !== 'live' ? $('vodSearch') : $('search'); sb.focus(); sb.select(); return; }
  if (typing || $('main').hidden || $('settings').open || (window.nlMode && window.nlMode !== 'live')) return;
  const k = e.key;
  if (k === ' ') { e.preventDefault(); togglePlay(); }
  else if (k === 'ArrowUp') { e.preventDefault(); step(-1); }
  else if (k === 'ArrowDown') { e.preventDefault(); step(1); }
  else if (k === 'ArrowLeft') { e.preventDefault(); seek(-10); }
  else if (k === 'ArrowRight') { e.preventDefault(); seek(10); }
  else if (k.toLowerCase() === 'f') fullscreen();
  else if (k.toLowerCase() === 'm') toggleMute();
  else if (k.toLowerCase() === 'p') pip();
  else if (k === 'Enter' && document.activeElement && document.activeElement._ch) select(document.activeElement._ch);
});

// redraw the times every minute
setInterval(() => {
  if ($('main').hidden) return;
  drawTimeline();
  document.querySelectorAll('.ch').forEach((r) => drawProgs(r.querySelector('.progs'), state.epg.get(r._ch.id)));
  if (state.playing) showInfo(state.playing);
}, 60000);

// ---------------- settings ----------------

$('settingsBtn').addEventListener('click', () => {
  drawSvcList();
  document.querySelectorAll('input[name=fmt]').forEach((r) => { r.checked = r.value === state.format; });
  $('ver').textContent = (window.northline && northline.version) || '';
  $('updMsg').textContent = '';
  $('settings').showModal();
});
$('closeSettings').addEventListener('click', () => $('settings').close());
document.querySelectorAll('input[name=fmt]').forEach((r) => r.addEventListener('change', () => {
  state.format = r.value; store.set('format', state.format);
  if (state.playing) start(state.playing, state.format);
}));
function drawSvcList() {
  const box = $('svcList'); box.innerHTML = '';
  state.services.forEach((s, i) => {
    const r = document.createElement('div'); r.className = 'svcRow';
    const t = document.createElement('span'); t.textContent = (s.name || s.server) + ' · ' + s.server + ' · ' + s.user; r.appendChild(t);
    const b = document.createElement('button'); b.className = 'ghost small'; b.textContent = 'Remove';
    b.addEventListener('click', () => {
      if (!confirm('Remove ' + (s.name || s.server) + ' from this computer?')) return;
      state.services.splice(i, 1); store.set('services', state.services);
      state.active = 0; store.set('active', 0);
      drawSvcList();
      if (!state.services.length) { $('settings').close(); stopPlayer(); showSignin(false); } else openService();
    });
    r.appendChild(b); box.appendChild(r);
  });
}

// updates: Northline for Windows and Mac lives on the same GitHub page as the Fire Stick app, as "desktop-v…" releases
const RELEASES = 'https://github.com/jasonchaplinski-commits/northline-tv/releases';
function newer(a, b) { const x = a.split('.').map(Number), y = b.split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; }
async function checkUpdate(loud) {
  try {
    const r = await fetch('https://api.github.com/repos/jasonchaplinski-commits/northline-tv/releases?per_page=30', { cache: 'no-store' });
    const list = await r.json();
    const d = (Array.isArray(list) ? list : []).find((x) => /^desktop-v/.test(x.tag_name || ''));
    const mine = (window.northline && northline.version) || '0.0.0';
    if (d && newer(d.tag_name.replace('desktop-v', ''), mine)) {
      const m = $('updMsg'); m.innerHTML = '';
      const a = document.createElement('a'); a.href = '#'; a.className = 'accent'; a.textContent = 'Version ' + d.tag_name.replace('desktop-v', '') + ' is ready: download it';
      a.addEventListener('click', (e) => { e.preventDefault(); window.northline && northline.openLink(d.html_url || RELEASES); });
      m.appendChild(a);
      if (!loud) { $('settingsBtn').textContent = 'Settings •'; $('settingsBtn').title = 'An update is ready'; }
    } else if (loud) $('updMsg').textContent = "You're on the newest version.";
  } catch (_) { if (loud) $('updMsg').textContent = "Couldn't check right now."; }
}
$('checkUpd').addEventListener('click', () => checkUpdate(true));

// ---------------- start ----------------

if (state.services.length) { if (state.active >= state.services.length) state.active = 0; openService(); } else showSignin(false);
setTimeout(() => checkUpdate(false), 5000);

// Settings › Add another service: same as the sidebar button
document.getElementById('settingsAdd').addEventListener('click', () => {
  document.getElementById('settings').close();
  document.getElementById('addSvc').click();
});
