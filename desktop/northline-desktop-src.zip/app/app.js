'use strict';
// Northline TV for Windows and Mac: your own Xtream TV services, a guide, and live TV.

const $ = (id) => document.getElementById(id);
const store = {
  get(k, d) { try { const v = localStorage.getItem('nl.' + k); return v == null ? d : JSON.parse(v); } catch (_) { return d; } },
  set(k, v) { try { localStorage.setItem('nl.' + k, JSON.stringify(v)); } catch (_) {} },
};

const state = {
  services: store.get('services', []),
  active: store.get('active', 0),
  cats: [], streams: [], byCat: new Map(),
  group: store.get('group', '__all'),
  query: '',
  shown: [], rendered: 0,
  playing: null,
  epg: new Map(),
  format: store.get('format', 'ts'),
};

// ---------------- TV service (Xtream) ----------------

function baseOf(server) {
  let s = String(server || '').trim().replace(/\/+$/, '');
  if (!/^https?:\/\//i.test(s)) s = 'http://' + s;
  return s;
}
const svc = () => state.services[state.active];
function api(s, action, extra = '') {
  const u = `${baseOf(s.server)}/player_api.php?username=${encodeURIComponent(s.user)}&password=${encodeURIComponent(s.pass)}` + (action ? `&action=${action}` : '') + extra;
  return fetch(u, { cache: 'no-store' }).then((r) => { if (!r.ok) throw new Error(r.status === 513 || r.status === 403 || r.status === 401 ? 'The server turned this computer away (' + r.status + '). Check the username and password, or that your plan allows another device right now.' : 'The server answered ' + r.status); return r.json(); });
}
function streamUrl(s, id, fmt) { return `${baseOf(s.server)}/live/${encodeURIComponent(s.user)}/${encodeURIComponent(s.pass)}/${id}.${fmt}`; }
const favKey = () => 'favs.' + (svc() ? baseOf(svc().server) + '|' + svc().user : '');
const favs = () => new Set(store.get(favKey(), []));

// ---------------- sign in ----------------

let addingExtra = false;
function showSignin(extra) {
  addingExtra = !!extra;
  $('signin').hidden = false; $('main').hidden = true;
  $('signinCancel').hidden = !extra;
  $('signinError').hidden = true;
  $('user').value = ''; $('pass').value = ''; $('svcName').value = '';
  setTimeout(() => $('user').focus(), 50);
}
document.querySelectorAll('input[name=server]').forEach((r) => r.addEventListener('change', () => {
  $('customServer').hidden = document.querySelector('input[name=server]:checked').value !== 'custom';
  if (!$('customServer').hidden) $('customServer').focus();
}));
$('signinCancel').addEventListener('click', () => { $('signin').hidden = true; $('main').hidden = false; });
$('signinForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  const pick = document.querySelector('input[name=server]:checked').value;
  const server = pick === 'custom' ? $('customServer').value.trim() : pick;
  const s = { server, user: $('user').value.trim(), pass: $('pass').value, name: $('svcName').value.trim() };
  const err = $('signinError');
  if (!s.server || !s.user || !s.pass) { err.textContent = 'Fill in the server, username and password.'; err.hidden = false; return; }
  $('signinBtn').disabled = true; $('signinBtn').textContent = 'Checking…'; err.hidden = true;
  try {
    const info = await api(s, '');
    if (!info || !info.user_info || String(info.user_info.auth) === '0') throw new Error('The server rejected this username or password.');
    if (!s.name) s.name = (s.server.split(/[.:]/)[0] || 'TV').slice(0, 14);
    const same = state.services.findIndex((x) => baseOf(x.server).toLowerCase() === baseOf(s.server).toLowerCase() && x.user === s.user);
    if (same >= 0) state.services[same] = s; else state.services.push(s);
    state.active = same >= 0 ? same : state.services.length - 1;
    store.set('services', state.services); store.set('active', state.active);
    $('signin').hidden = true;
    await openService();
  } catch (ex) {
    err.textContent = "Couldn't sign in: " + (ex.message === 'Failed to fetch' ? "the server didn't answer. Check the server name and your internet." : ex.message);
    err.hidden = false;
  } finally { $('signinBtn').disabled = false; $('signinBtn').textContent = 'Sign in'; }
});

// ---------------- loading a service ----------------

function fillServices() {
  const sel = $('svcSelect'); sel.innerHTML = '';
  state.services.forEach((s, i) => { const o = document.createElement('option'); o.value = i; o.textContent = s.name || s.server; sel.appendChild(o); });
  sel.value = state.active;
}
$('svcSelect').addEventListener('change', (e) => { state.active = +e.target.value; store.set('active', state.active); state.group = '__all'; openService(); });
$('addSvc').addEventListener('click', () => showSignin(true));

async function openService() {
  const s = svc(); if (!s) return showSignin(false);
  $('main').hidden = false; fillServices();
  if (window.vodReset) window.vodReset();
  $('list').innerHTML = '<div class="emptyMsg">Loading channels…</div>';
  $('groups').innerHTML = ''; state.epg.clear(); state.guideLoading = true; state.pendingEpg = new Set(); epgQ.length = 0;
  try {
    const [info, cats, streams] = await Promise.all([api(s, ''), api(s, 'get_live_categories'), api(s, 'get_live_streams')]);
    const exp = info && info.user_info && +info.user_info.exp_date;
    state.maxConn = info && info.user_info ? +info.user_info.max_connections || 0 : 0;
    if (exp) {
      const days = Math.ceil((exp * 1000 - Date.now()) / 86400000);
      $('expiry').textContent = 'Expires ' + new Date(exp * 1000).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) + ' · ' + days + ' days left';
      $('expiry').className = 'small ' + (days <= 7 ? 'error' : 'dim');
    } else $('expiry').textContent = '';
    state.cats = Array.isArray(cats) ? cats : [];
    state.streams = (Array.isArray(streams) ? streams : []).map((x, i) => ({
      id: String(x.stream_id), num: +x.num || i + 1, name: String(x.name || '').trim(), icon: x.stream_icon || '', cat: String(x.category_id || ''), epg: String(x.epg_channel_id || '').trim(),
    }));
    state.byCat = new Map();
    for (const x of state.streams) { if (!state.byCat.has(x.cat)) state.byCat.set(x.cat, []); state.byCat.get(x.cat).push(x); }
    drawGroups();
    showGroup(state.group);
    const last = store.get('last.' + favKey(), null);
    const ch = last && state.streams.find((x) => x.id === last);
    if (ch) select(ch, true);
    loadGuide(s);
  } catch (ex) {
    $('list').innerHTML = '';
    const m = document.createElement('div'); m.className = 'emptyMsg';
    m.textContent = "Couldn't load your channels: " + ex.message + '. Check your internet, or pick another service.';
    $('list').appendChild(m);
  }
}

// ---------------- groups ----------------

function drawGroups() {
  const g = $('groups'); g.innerHTML = '';
  const add = (id, label) => {
    const b = document.createElement('button'); b.textContent = label; b.dataset.id = id; b.title = label;
    b.addEventListener('click', () => { $('search').value = ''; state.query = ''; showGroup(id); });
    g.appendChild(b);
  };
  add('__fav', '★ Favorites'); add('__all', 'All channels');
  for (const c of state.cats) if (state.byCat.has(String(c.category_id))) add(String(c.category_id), String(c.category_name || '').trim());
  if (window.sportsAfterGroups) sportsAfterGroups();
}
function markGroup() { document.querySelectorAll('#groups button').forEach((b) => b.classList.toggle('on', b.dataset.id === state.group && !state.query)); }

function showGroup(id) {
  if (id !== '__fav' && id !== '__all' && !state.byCat.has(id)) id = '__all';
  state.group = id; store.set('group', id);
  const f = favs();
  state.shown = id === '__fav' ? state.streams.filter((x) => f.has(x.id)) : id === '__all' ? state.streams : state.byCat.get(id);
  markGroup(); drawList(id === '__fav' && !state.shown.length ? 'No favorites yet. Click ☆ on a channel to add it.' : 'No channels here.');
}

let searchTimer = 0;
$('search').addEventListener('input', () => {
  clearTimeout(searchTimer);
  searchTimer = setTimeout(() => {
    const q = $('search').value.trim().toLowerCase(); state.query = q;
    if (!q) return showGroup(state.group);
    const words = q.split(/\s+/);
    state.shown = state.streams.filter((x) => { const n = x.name.toLowerCase(); return words.every((w) => n.includes(w)); }).slice(0, 2000);
    markGroup(); drawList('No channels match “' + $('search').value.trim() + '”.');
  }, 200);
});

// ---------------- the guide list (drawn as you scroll) ----------------

const SLOT = 30 * 60000, WINDOW = 4 * SLOT;
let winStart = 0;
function drawTimeline() {
  const now = Date.now(); winStart = now - (now % SLOT);
  const t = $('timeline'); t.innerHTML = '';
  const day = document.createElement('span'); day.className = 'day';
  day.textContent = new Date().toLocaleString(undefined, { weekday: 'short', month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' });
  t.appendChild(day);
  for (let i = 0; i < 4; i++) { const s = document.createElement('span'); s.className = 'slot'; s.textContent = new Date(winStart + i * SLOT).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }); t.appendChild(s); }
}

const io = new IntersectionObserver((entries) => {
  for (const e of entries) if (e.isIntersecting) { io.unobserve(e.target); loadEpg(e.target._ch, e.target); }
}, { root: $('list'), rootMargin: '200px' });

function drawList(emptyText) {
  drawTimeline();
  const list = $('list'); list.innerHTML = ''; list.scrollTop = 0; state.rendered = 0;
  if (!state.shown.length) { const m = document.createElement('div'); m.className = 'emptyMsg'; m.textContent = emptyText; list.appendChild(m); return; }
  moreRows();
}
function moreRows() {
  const list = $('list'); const f = favs();
  const end = Math.min(state.shown.length, state.rendered + 120);
  for (let i = state.rendered; i < end; i++) list.appendChild(row(state.shown[i], f.has(state.shown[i].id)));
  state.rendered = end;
}
$('list').addEventListener('scroll', () => {
  const l = $('list'); if (l.scrollTop + l.clientHeight > l.scrollHeight - 600 && state.rendered < state.shown.length) moreRows();
});

function row(ch, isFav) {
  const r = document.createElement('div'); r.className = 'ch'; r.tabIndex = 0; r.setAttribute('role', 'listitem'); r._ch = ch; r.dataset.id = ch.id;
  if (state.playing && state.playing.id === ch.id) r.classList.add('on');
  const n = document.createElement('div'); n.className = 'name';
  const num = document.createElement('span'); num.className = 'num'; num.textContent = ch.num;
  n.appendChild(num);
  if (ch.icon) { const im = document.createElement('img'); im.className = 'icon'; im.loading = 'lazy'; im.alt = ''; im.src = ch.icon; im.onerror = () => im.remove(); n.appendChild(im); }
  const nm = document.createElement('span'); nm.className = 'nm'; nm.textContent = ch.name; n.appendChild(nm);
  const st = document.createElement('button'); st.className = 'star' + (isFav ? ' on' : ''); st.textContent = isFav ? '★' : '☆';
  st.title = isFav ? 'Remove from favorites' : 'Add to favorites'; st.setAttribute('aria-label', st.title);
  st.addEventListener('click', (e) => { e.stopPropagation(); toggleFav(ch, st); });
  n.appendChild(st);
  const p = document.createElement('div'); p.className = 'progs'; p._ch = ch;
  drawProgs(p, state.epg.get(ch.id));
  r.appendChild(n); r.appendChild(p);
  r.addEventListener('click', () => select(ch));
  r.addEventListener('dblclick', () => { select(ch); fullscreen(); });
  io.observe(r);
  return r;
}

function toggleFav(ch, btn) {
  const f = favs(); const on = !f.has(ch.id);
  if (on) f.add(ch.id); else f.delete(ch.id);
  store.set(favKey(), [...f]);
  btn.classList.toggle('on', on); btn.textContent = on ? '★' : '☆';
  if (state.group === '__fav' && !state.query) showGroup('__fav');
}

function b64(s) { try { return decodeURIComponent(escape(atob(s))); } catch (_) { return s || ''; } }
// The guide comes in one download (like the Fire Stick app). Only channels it doesn't cover ask the server
// one by one, two at a time, so a busy server like Alley Cat World isn't flooded with requests.
async function loadGuide(s, force) {
  state.guideLoading = true;
  let got = 0;
  try {
    const ids = [...new Set(state.streams.map((x) => x.epg).filter(Boolean))];
    if (ids.length && window.northline && northline.guide) {
      const data = await northline.guide({ base: baseOf(s.server), user: s.user, pass: s.pass, ids, force: !!force });
      if (svc() !== s) return;
      for (const ch of state.streams) { const l = ch.epg && data[ch.epg.toLowerCase()]; if (l && l.length) { state.epg.set(ch.id, l); got++; } }
    }
  } catch (_) {}
  if (svc() !== s) return;
  state.guideLoading = false;
  document.querySelectorAll('.ch').forEach((r) => drawProgs(r.querySelector('.progs'), state.epg.get(r._ch.id)));
  if (state.playing) showInfo(state.playing);
  if (window.sportsFill) await sportsFill(); // game channels first: they don't need the server at all
  if (svc() !== s) return;
  if (window.recRulesTick) recRulesTick();
  // then your other services and the backup guide; only what's still empty after that asks the server, gently
  if (window.fillGaps) await fillGaps(s, force);
  if (svc() !== s) return;
  for (const r of state.pendingEpg) if (r.isConnected && !state.epg.has(r._ch.id) && !(window.Names && (Names.eventTitle(r._ch.name) || Names.isNoEvent(r._ch.name)))) queueEpg(r._ch, r);
  state.pendingEpg.clear();
}
setInterval(() => { const s = svc(); if (s && !$('main').hidden && !state.guideLoading) loadGuide(s); }, 4 * 3600e3 + 60000);

function loadEpg(ch, r) {
  if (state.epg.has(ch.id)) return;
  if (window.Names && !state.guideLoading && (Names.eventTitle(ch.name) || Names.isNoEvent(ch.name)) && !state.epg.has(ch.id)) return;
  if (state.guideLoading) { state.pendingEpg.add(r); return; }
  queueEpg(ch, r);
}
const epgQ = []; let epgBusy = 0;
function queueEpg(ch, r) { epgQ.push([ch, r]); pumpEpg(); }
function pumpEpg() {
  while (epgBusy < 2 && epgQ.length) {
    const [ch, r] = epgQ.shift();
    if (!r.isConnected || state.epg.has(ch.id)) continue;
    epgBusy++; shortEpg(ch, r).finally(() => { epgBusy--; pumpEpg(); });
  }
}
async function shortEpg(ch, r) {
  if (!state.epg.has(ch.id)) state.epg.set(ch.id, null);
  const s = svc();
  try {
    const o = await api(s, 'get_short_epg', `&stream_id=${encodeURIComponent(ch.id)}&limit=6`);
    if (svc() !== s) return;
    const had = state.epg.get(ch.id); if (had && had.length) return; // filled meanwhile (backup guide): keep it
    const l = (o.epg_listings || []).map((e) => ({ start: +e.start_timestamp * 1000, stop: +(e.stop_timestamp || e.end_timestamp) * 1000, title: b64(e.title).trim(), desc: b64(e.description).trim() }))
      .filter((e) => e.start && e.stop > e.start).sort((a, b) => a.start - b.start);
    state.epg.set(ch.id, l);
    const p = r.querySelector('.progs'); if (p) drawProgs(p, l);
    if (state.playing && state.playing.id === ch.id) showInfo(ch);
  } catch (_) { if (!(state.epg.get(ch.id) || []).length) state.epg.set(ch.id, []); }
}

function drawProgs(p, l) {
  p.innerHTML = '';
  const end = winStart + WINDOW;
  const inWin = (l || []).filter((e) => e.stop > winStart && e.start < end);
  if (!inWin.length) {
    const d = document.createElement('div'); d.className = 'prog empty'; d.style.left = '0'; d.style.right = '0';
    d.textContent = l ? 'No information' : ''; p.appendChild(d);
  }
  for (const e of inWin) {
    const s = Math.max(e.start, winStart), t = Math.min(e.stop, end);
    const d = document.createElement('div'); d.className = 'prog';
    d.style.left = ((s - winStart) / WINDOW * 100) + '%'; d.style.width = ((t - s) / WINDOW * 100) + '%';
    d._e = e;
    const marked = window.recMarked && recMarked(p._ch, e);
    if (marked) d.classList.add('rec');
    if (window.gameBlock && gameBlock(d, e)) { if (marked) d.firstChild.textContent = '🔴 ' + d.firstChild.textContent; }
    else d.textContent = (marked ? '🔴 ' : '') + (e.title || 'No title');
    d.title = (marked ? 'Will record · ' : '') + e.title + '\n' + hhmm(e.start) + ' – ' + hhmm(e.stop) + (e.desc ? '\n\n' + e.desc : '');
    p.appendChild(d);
  }
  const nl = document.createElement('div'); nl.className = 'nowline'; nl.style.left = ((Date.now() - winStart) / WINDOW * 100) + '%'; p.appendChild(nl);
}
const hhmm = (t) => new Date(t).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });

// ---------------- the player ----------------

const video = $('video');
let mp = null, hls = null, tries = 0, lastTime = -1, stuckSince = 0;

// services that allow only one screen (Alley Cat World): the old channel has to be gone before the new one opens
const oneScreen = () => !state.alt && state.maxConn === 1;
let startTimer = null, retryTimer = null, busyTimer = null;

function stopPlayer() {
  clearTimeout(startTimer); clearTimeout(retryTimer);
  try { if (mp) { mp.pause(); mp.unload(); mp.detachMediaElement(); mp.destroy(); } } catch (_) {}
  try { if (hls) hls.destroy(); } catch (_) {}
  mp = null; hls = null; video.removeAttribute('src'); try { video.load(); } catch (_) {}
}
function msg(t) { const m = $('playerMsg'); m.textContent = t || ''; m.hidden = !t; }

function select(ch, quiet) {
  state.playing = ch; tries = 0; state.alt = null; hideBusy();
  store.set('last.' + favKey(), ch.id);
  document.querySelectorAll('.ch.on').forEach((x) => x.classList.remove('on'));
  const r = document.querySelector(`.ch[data-id="${CSS.escape(ch.id)}"]`); if (r) { r.classList.add('on'); if (!quiet) r.focus({ preventScroll: true }); }
  showInfo(ch);
  // close the old channel right away and open the new one straight after (a quarter second, so flipping
  // through channels only opens the one you stop on). Only waits if the server says your screen is still busy.
  stopPlayer(); msg('Loading ' + ch.name + '…');
  startTimer = setTimeout(() => state.playing === ch && start(ch, state.format), 250);
}
// leaving Live TV (Movies, Shows) really closes the channel, so a one-screen service can play the movie
function stopLive() { stopPlayer(); hideBusy(); msg(''); }
function resumeLive() { const ch = state.playing; if (ch && !mp && !hls) { tries = 0; stopPlayer(); msg('Loading ' + ch.name + '…'); startTimer = setTimeout(() => state.playing === ch && start(ch, state.format), 250); } }
window.stopLive = stopLive; window.resumeLive = resumeLive;

function start(ch, fmt) {
  stopPlayer();
  // a recording on this one-screen service is using the screen: say so instead of trying
  if (oneScreen() && window.recUsingScreen && recUsingScreen(svc())) return showBusy(ch, 'rec');
  const src = state.alt || { s: svc(), id: ch.id };
  msg('Loading ' + ch.name + (state.alt ? ' on ' + (src.s.name || src.s.server) : '') + '…');
  lastTime = -1; stuckSince = 0;
  const url = streamUrl(src.s, src.id, fmt);
  if (fmt === 'ts' && window.mpegts && mpegts.getFeatureList().mseLivePlayback) {
    mp = mpegts.createPlayer({ type: 'mpegts', isLive: true, url }, { enableWorker: false, enableStashBuffer: true, stashInitialSize: 384 * 1024, liveBufferLatencyChasing: false, lazyLoad: false });
    mp.attachMediaElement(video); mp.load();
    mp.on(mpegts.Events.ERROR, () => failed(ch, fmt));
    video.play().catch(() => {});
  } else if (window.Hls && Hls.isSupported()) {
    hls = new Hls({ lowLatencyMode: false, backBufferLength: 60 });
    hls.on(Hls.Events.ERROR, (_, d) => { if (d.fatal) failed(ch, fmt); });
    hls.loadSource(streamUrl(src.s, src.id, 'm3u8')); hls.attachMedia(video);
    hls.on(Hls.Events.MANIFEST_PARSED, () => video.play().catch(() => {}));
  } else { video.src = url; video.play().catch(() => {}); }
}

// how many screens the service says are in use right now
function screens(s) {
  return api(s, '').then((i) => ({ active: +((i.user_info || {}).active_cons || 0), max: +((i.user_info || {}).max_connections || 0) })).catch(() => null);
}

// a channel that won't load tries again, then the other stream format, before giving up
function failed(ch, fmt) {
  if (!state.playing || state.playing.id !== ch.id) return;
  tries++;
  const other = fmt === 'ts' ? 'm3u8' : 'ts';
  stopPlayer();
  if (oneScreen()) {
    // one screen: the server may still be closing the old channel, so one quick retry, then ask it how many screens are in use
    if (tries === 1) { msg('Connecting…'); retryTimer = setTimeout(() => state.playing === ch && start(ch, fmt), 1200); return; }
    msg('Checking your screen…');
    screens(svc()).then((n) => {
      if (state.playing !== ch || mp || hls) return;
      if (n && n.max && n.active >= n.max) showBusy(ch, 'busy');
      else if (tries <= 4) { msg('Connecting…'); retryTimer = setTimeout(() => state.playing === ch && start(ch, fmt), 2000); }
      else showBusy(ch, 'fail');
    });
    return;
  }
  if (tries === 1) { msg('Reconnecting…'); retryTimer = setTimeout(() => state.playing === ch && start(ch, fmt), 1500); }
  else if (tries === 2) { msg('Trying the other stream format…'); start(ch, other); }
  else if (tries <= 4) { msg('Reconnecting…'); retryTimer = setTimeout(() => state.playing === ch && start(ch, tries % 2 ? fmt : other), 4000); }
  else if (state.services.length > 1) showBusy(ch, 'fail');
  else msg("Can't play " + ch.name + ' right now. Try another channel, or another service.');
}

// ---- the screen is busy: say why, offer the same channel on another service, and start by itself when it frees
function showBusy(ch, why) {
  msg('');
  const s = svc(), name = s.name || s.server;
  $('busyTitle').textContent = why === 'fail' ? "Can't play " + ch.name + ' right now' : name + "'s one screen is in use";
  $('busyText').textContent = why === 'rec' ? 'A recording is using ' + name + "'s only screen. Watch something on another service until it's done."
    : why === 'fail' ? name + " isn't answering for this channel."
    : 'Another device is watching ' + name + ' right now (1 of 1 screens). Stop it there, or:';
  $('busyAlt').hidden = true;
  $('busyBox').hidden = false; box.classList.add('ui');
  findAlt(ch).then((a) => {
    if (state.playing !== ch || $('busyBox').hidden || !a) return;
    $('busyAlt').textContent = '▶ Watch on ' + (a.s.name || a.s.server) + ' instead';
    $('busyAlt').hidden = false;
    $('busyAlt').onclick = () => { hideBusy(); state.alt = a; tries = 0; showInfo(ch); start(ch, state.format); };
  });
  $('busyRetry').onclick = () => { hideBusy(); tries = 0; start(ch, state.format); };
  clearInterval(busyTimer);
  if (why !== 'fail') busyTimer = setInterval(async () => {
    if (state.playing !== ch || $('busyBox').hidden) return clearInterval(busyTimer);
    if (why === 'rec' ? !recUsingScreen(svc()) : ((n) => n && n.max && n.active < n.max)(await screens(svc()))) { hideBusy(); tries = 0; start(ch, state.format); }
  }, 5000);
}
function hideBusy() { clearInterval(busyTimer); const b = $('busyBox'); if (b) b.hidden = true; }

// the same channel on your other services: "## 24/7 COMEDY RAW 60fps ##" and "US| 24/7 Comedy HD" match
const otherLists = new Map();
const normName = (n) => String(n || '').toLowerCase().replace(/\[[^\]]*\]|\([^)]*\)/g, ' ').replace(/^\s*[#\s]*[a-z]{2,3}\s*[|:\-]\s*/, '')
  .replace(/\b(raw|60fps|50fps|fhd|uhd|hd|sd|4k|hevc|h265|backup|live)\b/g, ' ').replace(/[^a-z0-9]+/g, '');
async function findAlt(ch) {
  const want = normName(ch.name); if (!want) return null;
  for (const s of state.services) {
    if (s === svc()) continue;
    const k = baseOf(s.server) + '|' + s.user;
    let list = otherLists.get(k);
    if (!list) { try { list = await api(s, 'get_live_streams'); } catch (_) { list = []; } otherLists.set(k, Array.isArray(list) ? list : []); list = otherLists.get(k); }
    const hit = list.find((x) => normName(x.name) === want);
    if (hit) return { s, id: String(hit.stream_id), name: String(hit.name || '').trim() };
  }
  return null;
}

video.addEventListener('playing', () => { msg(''); tries = 0; });
video.addEventListener('waiting', () => { if (!video.paused) stuckSince = stuckSince || Date.now(); });
// every 3 seconds: is the picture moving? stuck for 12 s while playing = reconnect (like the Fire Stick app)
setInterval(() => {
  const ch = state.playing; if (!ch || (!mp && !hls) || video.paused || document.hidden && !document.pictureInPictureElement) return;
  const t = video.currentTime;
  if (t === lastTime) { stuckSince = stuckSince || Date.now(); if (Date.now() - stuckSince > 12000) { stuckSince = 0; msg('Reconnecting…'); start(ch, state.format); } }
  else { stuckSince = 0; }
  lastTime = t;
}, 3000);

function showInfo(ch) {
  const l = state.epg.get(ch.id) || []; const now = Date.now();
  const cur = l.find((e) => e.start <= now && e.stop > now);
  const next = l.find((e) => e.start > now);
  $('infoCh').textContent = ch.num + '  ' + ch.name + (state.alt && state.playing === ch ? '   ·   playing on ' + (state.alt.s.name || state.alt.s.server) : '');
  $('infoTitle').textContent = cur ? cur.title : ch.name;
  $('infoTime').textContent = cur ? hhmm(cur.start) + ' – ' + hhmm(cur.stop) + ' · ' + Math.max(1, Math.round((cur.stop - now) / 60000)) + ' min left' + (next ? '   ·   Next: ' + next.title + ' ' + hhmm(next.start) : '') : 'No program information';
  $('infoDesc').textContent = cur ? cur.desc : '';
  document.title = ch.name + ' · Northline TV';
}

function fullscreen() { const b = $('playerBox'); if (document.fullscreenElement) document.exitFullscreen(); else b.requestFullscreen().catch(() => {}); }
function togglePlay() { if (video.paused) video.play().catch(() => {}); else video.pause(); }
function toggleMute() { video.muted = !video.muted; }
async function pip() { try { if (document.pictureInPictureElement) await document.exitPictureInPicture(); else await video.requestPictureInPicture(); } catch (_) {} }
function seek(s) {
  const b = video.buffered; if (!b.length) return;
  video.currentTime = Math.min(b.end(b.length - 1) - 0.5, Math.max(b.start(0), video.currentTime + s));
}

$('playPause').addEventListener('click', togglePlay);
$('muteBtn').addEventListener('click', toggleMute);
$('fsBtn').addEventListener('click', fullscreen);
$('pipBtn').addEventListener('click', pip);
$('volume').addEventListener('input', (e) => { video.volume = +e.target.value; video.muted = false; store.set('volume', video.volume); });
video.volume = store.get('volume', 1); $('volume').value = video.volume;
// a click on the picture shows the bar and keeps playing; double-click is full screen; pause is ❚❚ or Space only
video.addEventListener('dblclick', fullscreen);
video.addEventListener('click', () => wake());
video.addEventListener('play', () => { $('playPause').textContent = '❚❚'; liveUi(); });
video.addEventListener('pause', () => { $('playPause').textContent = '▶'; liveUi(); });
$('pauseBig').addEventListener('click', () => { video.play().catch(() => {}); wake(); });
$('liveBtn').addEventListener('click', goLive);

const box = $('playerBox'); let uiTimer = null;
function wake() {
  box.classList.add('ui'); clearTimeout(uiTimer);
  uiTimer = setTimeout(function hide() {
    if ($('playerBar').matches(':hover')) { uiTimer = setTimeout(hide, 1000); return; } // never vanish under the mouse
    box.classList.remove('ui');
  }, 3000);
}
box.addEventListener('mousemove', wake);
box.addEventListener('mouseleave', () => { clearTimeout(uiTimer); box.classList.remove('ui'); });

// how far behind live: the newest picture we have minus what's showing
function behindSec() { const b = video.buffered; return b.length ? Math.max(0, b.end(b.length - 1) - video.currentTime) : 0; }
const mmss = (t) => Math.floor(t / 60) + ':' + String(Math.floor(t % 60)).padStart(2, '0');
function liveUi() {
  const on = !!(state.playing && (mp || hls));
  const behind = on ? behindSec() : 0;
  const atLive = !video.paused && behind < 6;
  $('liveBtn').classList.toggle('on', atLive);
  $('liveBtn').textContent = atLive ? '● LIVE' : '⏭ LIVE';
  $('behind').textContent = atLive || !on || behind < 1 ? '' : '−' + mmss(behind);
  const paused = on && video.paused && $('playerMsg').hidden;
  box.classList.toggle('paused', paused);
  $('pauseBig').hidden = !paused; $('pausedTag').hidden = !paused;
  if (paused) $('pausedTag').textContent = 'Paused' + (behind >= 1 ? ' · −' + mmss(behind) : '');
}
setInterval(liveUi, 1000);
// back to live: jump to the newest picture, or reopen the channel if we've been away too long
function goLive() {
  const ch = state.playing; if (!ch) return;
  const b = video.buffered;
  if (!b.length || behindSec() > 600) { tries = 0; start(ch, state.format); }
  else { video.currentTime = b.end(b.length - 1) - 1; video.play().catch(() => {}); }
  wake(); setTimeout(liveUi, 300);
}
video.addEventListener('volumechange', () => { $('muteBtn').textContent = video.muted ? '🔇' : '🔊'; });

function step(d) {
  const list = state.shown; if (!list.length) return;
  const i = state.playing ? list.findIndex((x) => x.id === state.playing.id) : -1;
  const n = list[(i + d + list.length) % list.length];
  const idx = list.indexOf(n);
  while (state.rendered <= idx) moreRows();
  select(n);
  const r = document.querySelector(`.ch[data-id="${CSS.escape(n.id)}"]`); if (r) r.scrollIntoView({ block: 'nearest' });
}

document.addEventListener('keydown', (e) => {
  const typing = /^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement && document.activeElement.tagName) && document.activeElement.type !== 'range' && document.activeElement.type !== 'radio';
  if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'f') { e.preventDefault(); const sb = window.nlMode && window.nlMode !== 'live' ? $('vodSearch') : $('search'); sb.focus(); sb.select(); return; }
  if (typing || $('main').hidden || $('settings').open || (window.nlMode && window.nlMode !== 'live')) return;
  const k = e.key;
  if (document.fullscreenElement) wake();
  if (k === ' ') { e.preventDefault(); togglePlay(); }
  else if (k.toLowerCase() === 'l') goLive();
  else if (k === 'ArrowUp') { e.preventDefault(); step(-1); }
  else if (k === 'ArrowDown') { e.preventDefault(); step(1); }
  else if (k === 'ArrowLeft') { e.preventDefault(); seek(-10); }
  else if (k === 'ArrowRight') { e.preventDefault(); seek(10); }
  else if (k.toLowerCase() === 'f') fullscreen();
  else if (k.toLowerCase() === 'm') toggleMute();
  else if (k.toLowerCase() === 'p') pip();
  else if (k === 'Enter' && document.activeElement && document.activeElement._ch) select(document.activeElement._ch);
});

// redraw the times every minute
setInterval(() => {
  if ($('main').hidden) return;
  drawTimeline();
  document.querySelectorAll('.ch').forEach((r) => drawProgs(r.querySelector('.progs'), state.epg.get(r._ch.id)));
  if (state.playing) showInfo(state.playing);
}, 60000);

// ---------------- settings ----------------

$('settingsBtn').addEventListener('click', () => {
  drawSvcList();
  document.querySelectorAll('input[name=fmt]').forEach((r) => { r.checked = r.value === state.format; });
  $('ver').textContent = (window.northline && northline.version) || '';
  $('updMsg').textContent = '';
  $('settings').showModal();
});
$('closeSettings').addEventListener('click', () => $('settings').close());
document.querySelectorAll('input[name=fmt]').forEach((r) => r.addEventListener('change', () => {
  state.format = r.value; store.set('format', state.format);
  if (state.playing) start(state.playing, state.format);
}));
function drawSvcList() {
  const box = $('svcList'); box.innerHTML = '';
  state.services.forEach((s, i) => {
    const r = document.createElement('div'); r.className = 'svcRow';
    const t = document.createElement('span'); t.textContent = (s.name || s.server) + ' · ' + s.server + ' · ' + s.user; r.appendChild(t);
    const lb = document.createElement('button'); lb.className = 'ghost small'; lb.textContent = '🔑 Login details';
    lb.addEventListener('click', () => showLogin(s)); r.appendChild(lb);
    const b = document.createElement('button'); b.className = 'ghost small'; b.textContent = 'Remove';
    b.addEventListener('click', () => {
      if (!confirm('Remove ' + (s.name || s.server) + ' from this computer?')) return;
      state.services.splice(i, 1); store.set('services', state.services);
      state.active = 0; store.set('active', 0);
      drawSvcList();
      if (!state.services.length) { $('settings').close(); stopPlayer(); showSignin(false); } else openService();
    });
    r.appendChild(b); box.appendChild(r);
  });
}

// Login details: server, username, password, expiry and screens in use (like TiviMate's Xtream Codes parameters)
function lookAlikes(t) {
  const l = [];
  if (t.includes('0')) l.push('0 = zero'); if (t.includes('O')) l.push('O = capital letter O'); if (t.includes('o')) l.push('o = small letter o');
  if (t.includes('1')) l.push('1 = one'); if (t.includes('l')) l.push('l = small L'); if (t.includes('I')) l.push('I = capital i');
  if (/[a-z]/i.test(t) && !/[A-Z]/.test(t)) l.push('all letters are small');
  return l.join('  ·  ');
}
async function showLogin(s) {
  $('loginTitle').textContent = 'Login details · ' + (s.name || s.server);
  const box = $('loginRows'); box.innerHTML = '';
  for (const [k, v] of [['Server address', baseOf(s.server)], ['Username', s.user], ['Password', s.pass], ['Output format', 'MPEG-TS']]) {
    const r = document.createElement('div'); r.className = 'loginRow';
    const a = document.createElement('div'); a.className = 'dim'; a.textContent = k;
    const b = document.createElement('div'); b.textContent = v;
    r.appendChild(a); r.appendChild(b); box.appendChild(r);
  }
  $('loginHint').textContent = lookAlikes(s.pass);
  $('loginStatus').textContent = 'Checking with the server…';
  $('loginDlg').showModal();
  try {
    const i = (await api(s, '')).user_info || {};
    const exp = +i.exp_date;
    const max = i.max_connections, act = i.active_cons || '0';
    $('loginStatus').textContent = [
      String(i.auth) === '0' ? "The server didn't accept this login" : (i.status || 'Signed in'),
      max ? act + ' of ' + max + ' screen' + (max == 1 ? '' : 's') + ' in use' : '',
      exp ? 'Expires ' + new Date(exp * 1000).toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' }) : '',
    ].filter(Boolean).join('  ·  ');
  } catch (ex) { $('loginStatus').textContent = "Couldn't reach the server: " + ex.message; }
}
$('loginClose').addEventListener('click', () => $('loginDlg').close());

// updates: Northline for Windows and Mac lives on the same GitHub page as the Fire Stick app, as "desktop-v…" releases
const RELEASES = 'https://github.com/jasonchaplinski-commits/northline-tv/releases';
function newer(a, b) { const x = a.split('.').map(Number), y = b.split('.').map(Number); for (let i = 0; i < 3; i++) { if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) > (y[i] || 0); } return false; }
async function checkUpdate(loud) {
  try {
    const r = await fetch('https://api.github.com/repos/jasonchaplinski-commits/northline-tv/releases?per_page=30', { cache: 'no-store' });
    const list = await r.json();
    const d = (Array.isArray(list) ? list : []).find((x) => /^desktop-v/.test(x.tag_name || ''));
    const mine = (window.northline && northline.version) || '0.0.0';
    if (d && newer(d.tag_name.replace('desktop-v', ''), mine)) {
      const m = $('updMsg'); m.innerHTML = '';
      const a = document.createElement('a'); a.href = '#'; a.className = 'accent'; a.textContent = 'Version ' + d.tag_name.replace('desktop-v', '') + ' is ready: download it';
      a.addEventListener('click', (e) => { e.preventDefault(); window.northline && northline.openLink(d.html_url || RELEASES); });
      m.appendChild(a);
      if (!loud) { $('settingsBtn').textContent = 'Settings •'; $('settingsBtn').title = 'An update is ready'; }
    } else if (loud) $('updMsg').textContent = "You're on the newest version.";
  } catch (_) { if (loud) $('updMsg').textContent = "Couldn't check right now."; }
}
$('checkUpd').addEventListener('click', () => checkUpdate(true));

// ---------------- start ----------------

if (state.services.length) { if (state.active >= state.services.length) state.active = 0; openService(); } else showSignin(false);
setTimeout(() => checkUpdate(false), 5000);

// Settings › Add another service: same as the sidebar button
document.getElementById('settingsAdd').addEventListener('click', () => {
  document.getElementById('settings').close();
  document.getElementById('addSvc').click();
});
