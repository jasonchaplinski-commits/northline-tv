'use strict';
// Movies and Shows: categories, posters, details, seasons and episodes, resume and My list.

window.nlMode = 'live';
const vod = {
  kind: 'movie',            // movie | series
  cats: { movie: null, series: null },
  cat: null,                // category id, or __continue / __mylist / __search
  items: [], rendered: 0,
  all: { movie: null, series: null }, // the whole list, read once for search
  current: null,            // the movie or show in the details window
  info: null,
  season: null,
  playing: null,            // { item, ep, url, key }
  queue: [],
};

const vodKey = (k) => 'vod.' + k + '.' + (svc() ? baseOf(svc().server) + '|' + svc().user : '');
const resumeAll = () => store.get(vodKey('resume'), {});
const myList = () => store.get(vodKey('mylist'), []);
const itemKey = (it) => (it.kind === 'series' ? 's:' : 'm:') + it.id;

window.vodReset = function () {
  vod.cats = { movie: null, series: null }; vod.all = { movie: null, series: null }; vod.cat = null;
  setMode('live');
};

// ---------------- tabs: Live TV / Movies / Shows ----------------

document.querySelectorAll('#modes button').forEach((b) => b.addEventListener('click', () => setMode(b.dataset.mode)));

function setMode(m) {
  window.nlMode = m;
  document.querySelectorAll('#modes button').forEach((b) => b.classList.toggle('on', b.dataset.mode === m));
  const live = m === 'live';
  ['search', 'groups', 'top', 'timeline', 'list'].forEach((id) => { $(id).hidden = !live; });
  ['vodSearch', 'vodGroups', 'vodView'].forEach((id) => { $(id).hidden = live; });
  if (live) { if (window.resumeLive) resumeLive(); return; }
  if (window.stopLive) stopLive(); // the live channel stops (and lets go of the connection) while you browse movies
  vod.kind = m;
  $('vodSearch').value = '';
  $('vodSearch').placeholder = m === 'movie' ? 'Search all movies  (Ctrl+F)' : 'Search all shows  (Ctrl+F)';
  loadCats();
}

// ---------------- categories ----------------

async function loadCats() {
  const k = vod.kind, g = $('vodGroups');
  g.innerHTML = '';
  if (!vod.cats[k]) {
    $('vodStatus').textContent = 'Loading categories…';
    try { const c = await api(svc(), k === 'movie' ? 'get_vod_categories' : 'get_series_categories'); vod.cats[k] = Array.isArray(c) ? c : []; }
    catch (ex) { $('vodStatus').textContent = "Couldn't load " + (k === 'movie' ? 'movies' : 'shows') + ': ' + ex.message; return; }
  }
  if (vod.kind !== k) return;
  const add = (id, label) => {
    const b = document.createElement('button'); b.textContent = label; b.title = label; b.dataset.id = id;
    b.addEventListener('click', () => openCat(id, label)); g.appendChild(b);
  };
  add('__continue', 'Continue watching'); add('__mylist', '★ My list');
  for (const c of vod.cats[k]) add(String(c.category_id), String(c.category_name || '').trim());
  const hasResume = Object.values(resumeAll()).some((r) => r.item && r.item.kind === k);
  const first = hasResume ? '__continue' : (vod.cats[k][0] ? String(vod.cats[k][0].category_id) : '__mylist');
  const label = (g.querySelector(`button[data-id="${CSS.escape(first)}"]`) || {}).textContent || '';
  openCat(first, label);
}

function markCat() { document.querySelectorAll('#vodGroups button').forEach((b) => b.classList.toggle('on', b.dataset.id === vod.cat)); }

async function openCat(id, label) {
  vod.cat = id; markCat();
  $('vodTitle').textContent = label || (vod.kind === 'movie' ? 'Movies' : 'Shows');
  const k = vod.kind;
  if (id === '__continue') {
    const l = Object.values(resumeAll()).filter((r) => r.item && r.item.kind === k).sort((a, b) => b.at - a.at).map((r) => r.item);
    const seen = new Set(); return showItems(l.filter((x) => !seen.has(itemKey(x)) && seen.add(itemKey(x))), 'Nothing in progress yet.');
  }
  if (id === '__mylist') return showItems(myList().filter((x) => x.kind === k), 'Nothing here yet. Open a title and choose ★ Add to My list.');
  $('vodStatus').textContent = 'Loading…'; $('vodGrid').innerHTML = '';
  try {
    const l = await api(svc(), k === 'movie' ? 'get_vod_streams' : 'get_series', '&category_id=' + encodeURIComponent(id));
    if (vod.cat !== id || vod.kind !== k) return;
    showItems((Array.isArray(l) ? l : []).map((x) => toItem(x, k, label)), 'No titles here.');
  } catch (ex) { if (vod.cat === id) $('vodStatus').textContent = "Couldn't load this category: " + ex.message; }
}

function toItem(x, kind, cat) {
  const name = String(x.name || '').trim();
  const yr = (String(x.releaseDate || x.release_date || '').match(/\d{4}/) || name.match(/\((19|20)\d{2}\)/) || [''])[0].replace(/\D/g, '');
  return kind === 'movie'
    ? { kind, id: String(x.stream_id), name, icon: x.stream_icon || '', ext: x.container_extension || 'mp4', rating: x.rating || '', year: yr, cat: cat || '' }
    : { kind, id: String(x.series_id), name, icon: x.cover || '', rating: x.rating || '', year: yr, plot: x.plot || '', cat: cat || '' };
}

// ---------------- the poster grid (drawn as you scroll) ----------------

function showItems(list, empty) {
  vod.items = list; vod.rendered = 0;
  const g = $('vodGrid'); g.innerHTML = ''; g.scrollTop = 0;
  $('vodStatus').textContent = list.length ? list.length.toLocaleString() + ' titles' : '';
  if (!list.length) { const m = document.createElement('div'); m.className = 'emptyMsg'; m.textContent = empty; g.appendChild(m); return; }
  moreTiles();
}
function moreTiles() {
  const g = $('vodGrid'); const res = resumeAll();
  const end = Math.min(vod.items.length, vod.rendered + 90);
  for (let i = vod.rendered; i < end; i++) g.appendChild(tile(vod.items[i], res));
  vod.rendered = end;
}
$('vodGrid').addEventListener('scroll', () => {
  const g = $('vodGrid'); if (g.scrollTop + g.clientHeight > g.scrollHeight - 700 && vod.rendered < vod.items.length) moreTiles();
});

function tile(it, res) {
  const t = document.createElement('div'); t.className = 'tile'; t.tabIndex = 0; t.setAttribute('role', 'button'); t.setAttribute('aria-label', it.name);
  const p = document.createElement('div'); p.className = 'poster';
  if (it.icon) { const im = new Image(); im.onload = () => { p.style.backgroundImage = `url("${it.icon.replace(/"/g, '%22')}")`; p.firstChild && (p.firstChild.textContent = ''); }; im.src = it.icon; }
  const ph = document.createElement('span'); ph.textContent = it.name; p.appendChild(ph);
  t.appendChild(p);
  const r = res[itemKey(it)];
  if (r && r.dur > 0 && it.kind === 'movie') { const b = document.createElement('div'); b.className = 'bar'; const i = document.createElement('i'); i.style.width = Math.min(100, r.pos / r.dur * 100) + '%'; b.appendChild(i); t.appendChild(b); }
  const n = document.createElement('div'); n.className = 't'; n.textContent = it.name; t.appendChild(n);
  const m = document.createElement('div'); m.className = 'm'; m.textContent = [it.year, it.rating && it.rating !== '0' ? '★ ' + it.rating : ''].filter(Boolean).join('  ·  ') || ' '; t.appendChild(m);
  t.addEventListener('click', () => openDetail(it));
  t.addEventListener('keydown', (e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); openDetail(it); } });
  return t;
}

// ---------------- search every category ----------------

let vodSearchTimer = 0;
$('vodSearch').addEventListener('input', () => {
  clearTimeout(vodSearchTimer);
  vodSearchTimer = setTimeout(async () => {
    const q = $('vodSearch').value.trim().toLowerCase(), k = vod.kind;
    if (!q) { const b = document.querySelector('#vodGroups button.on') || document.querySelector('#vodGroups button'); return b && openCat(b.dataset.id, b.textContent); }
    vod.cat = '__search'; markCat(); $('vodTitle').textContent = 'Search: ' + $('vodSearch').value.trim();
    if (!vod.all[k]) {
      $('vodStatus').textContent = 'Getting the full list (first search takes a few seconds)…';
      try {
        const l = await api(svc(), k === 'movie' ? 'get_vod_streams' : 'get_series');
        const names = new Map((vod.cats[k] || []).map((c) => [String(c.category_id), String(c.category_name || '').trim()]));
        vod.all[k] = (Array.isArray(l) ? l : []).map((x) => toItem(x, k, names.get(String(x.category_id)) || ''));
      } catch (ex) { $('vodStatus').textContent = 'Search failed: ' + ex.message; return; }
    }
    if ($('vodSearch').value.trim().toLowerCase() !== q || vod.kind !== k) return;
    const words = q.split(/\s+/);
    const hits = vod.all[k].filter((x) => { const n = x.name.toLowerCase(); return words.every((w) => n.includes(w)); })
      .sort((a, b) => (b.name.toLowerCase().startsWith(words[0]) - a.name.toLowerCase().startsWith(words[0])) || a.name.localeCompare(b.name)).slice(0, 1500);
    showItems(hits, 'Nothing matches “' + $('vodSearch').value.trim() + '”.');
  }, 350);
});

// ---------------- details: a movie, or a show with seasons and episodes ----------------

const fmtMin = (sec) => { const m = Math.round(sec / 60); return m >= 60 ? Math.floor(m / 60) + 'h ' + (m % 60) + 'm' : m + ' min'; };

async function openDetail(it) {
  vod.current = it; vod.info = null; vod.season = null;
  const d = $('detail');
  $('dTitle').textContent = it.name; $('dMeta').textContent = [it.year, it.cat].filter(Boolean).join('  ·  ');
  $('dPlot').textContent = it.plot || 'Loading…'; $('dCast').textContent = '';
  $('dPoster').src = it.icon || ''; $('dPoster').hidden = !it.icon;
  $('dSeasons').innerHTML = ''; $('dEpisodes').innerHTML = '';
  $('dPlay').hidden = it.kind === 'series'; $('dResume').hidden = true;
  drawListBtn();
  const r = resumeAll()[itemKey(it)];
  if (it.kind === 'movie' && r && r.pos > 30 && r.dur && r.pos < r.dur * 0.95) { $('dResume').hidden = false; $('dResume').textContent = '▶ Resume at ' + fmtMin(r.pos); $('dPlay').textContent = '▶ Play from start'; }
  else $('dPlay').textContent = '▶ Play';
  if (!d.open) d.showModal();
  try {
    const o = it.kind === 'movie'
      ? await api(svc(), 'get_vod_info', '&vod_id=' + encodeURIComponent(it.id))
      : await api(svc(), 'get_series_info', '&series_id=' + encodeURIComponent(it.id));
    if (vod.current !== it) return;
    vod.info = o;
    const inf = (o && o.info) || {};
    $('dPlot').textContent = (inf.plot || inf.description || it.plot || '').trim() || 'No description.';
    $('dCast').textContent = [inf.director ? 'Director: ' + inf.director : '', inf.cast || inf.actors ? 'Cast: ' + (inf.cast || inf.actors) : ''].filter(Boolean).join('\n');
    const yr = (String(inf.releasedate || inf.releaseDate || '').match(/\d{4}/) || [it.year])[0];
    const dur = +inf.duration_secs || 0;
    $('dMeta').textContent = [yr, inf.genre, dur ? fmtMin(dur) : '', inf.rating && inf.rating !== '0' ? '★ ' + inf.rating : ''].filter(Boolean).join('  ·  ');
    if (!it.icon && (inf.movie_image || inf.cover)) { $('dPoster').src = inf.movie_image || inf.cover; $('dPoster').hidden = false; }
    if (it.kind === 'series') drawSeasons(o);
  } catch (ex) { if (vod.current === it) $('dPlot').textContent = "Couldn't load the details: " + ex.message; }
}

function drawListBtn() {
  const it = vod.current; const on = myList().some((x) => itemKey(x) === itemKey(it));
  $('dList').textContent = on ? '★ In My list' : '☆ Add to My list';
}
$('dList').addEventListener('click', () => {
  const it = vod.current; let l = myList(); const k = itemKey(it);
  l = l.some((x) => itemKey(x) === k) ? l.filter((x) => itemKey(x) !== k) : [it].concat(l);
  store.set(vodKey('mylist'), l.slice(0, 500)); drawListBtn();
  if (vod.cat === '__mylist') openCat('__mylist', '★ My list');
});
$('dClose').addEventListener('click', () => $('detail').close());
$('dPlay').addEventListener('click', () => playMovie(vod.current, 0));
$('dResume').addEventListener('click', () => { if (vod.current.kind !== 'movie') return; const r = resumeAll()[itemKey(vod.current)]; playMovie(vod.current, r ? r.pos : 0); });

function episodesOf(o) {
  const eps = []; const raw = (o && o.episodes) || {};
  for (const [s, list] of Object.entries(raw)) for (const e of (list || [])) {
    eps.push({ id: String(e.id), season: +(e.season || s) || 1, num: +e.episode_num || 0, title: String(e.title || '').trim(), ext: e.container_extension || 'mp4',
      plot: (e.info && e.info.plot) || '', dur: (e.info && +e.info.duration_secs) || 0 });
  }
  return eps.sort((a, b) => a.season - b.season || a.num - b.num);
}

function drawSeasons(o) {
  const eps = episodesOf(o); vod.queue = eps;
  const seasons = [...new Set(eps.map((e) => e.season))];
  const box = $('dSeasons'); box.innerHTML = '';
  if (!eps.length) { $('dEpisodes').innerHTML = '<p class="dim">No episodes listed.</p>'; return; }
  // start on the season you were watching
  const r = resumeAll()[itemKey(vod.current)];
  const startSeason = r && r.ep ? r.ep.season : seasons[0];
  for (const s of seasons) {
    const b = document.createElement('button'); b.className = 'ghost small'; b.textContent = 'Season ' + s; b.dataset.s = s;
    b.addEventListener('click', () => showSeason(s)); box.appendChild(b);
  }
  if (r && r.ep) { $('dResume').hidden = false; $('dResume').textContent = '▶ Resume S' + r.ep.season + ' E' + r.ep.num + (r.pos > 30 ? ' at ' + fmtMin(r.pos) : ''); }
  showSeason(seasons.includes(startSeason) ? startSeason : seasons[0]);
}
$('dResume').addEventListener('click', () => {
  if (vod.current && vod.current.kind === 'series') {
    const r = resumeAll()[itemKey(vod.current)]; const ep = r && r.ep && vod.queue.find((e) => e.id === r.ep.id);
    if (ep) playEpisode(vod.current, ep, r.pos > 30 && r.dur && r.pos < r.dur * 0.95 ? r.pos : 0);
  }
});

function showSeason(s) {
  vod.season = s;
  document.querySelectorAll('#dSeasons button').forEach((b) => b.classList.toggle('on', +b.dataset.s === s));
  const box = $('dEpisodes'); box.innerHTML = '';
  const watched = store.get(vodKey('watched'), {});
  for (const e of vod.queue.filter((x) => x.season === s)) {
    const row = document.createElement('div'); row.className = 'ep'; row.tabIndex = 0; row.setAttribute('role', 'button');
    const n = document.createElement('b'); n.textContent = 'E' + e.num; row.appendChild(n);
    const t = document.createElement('div'); t.className = 'et';
    const a = document.createElement('div'); a.textContent = e.title || 'Episode ' + e.num; t.appendChild(a);
    const sm = document.createElement('small'); sm.textContent = [e.dur ? fmtMin(e.dur) : '', e.plot].filter(Boolean).join(' · '); t.appendChild(sm);
    row.appendChild(t);
    if (watched[e.id]) { const w = document.createElement('span'); w.className = 'watched'; w.textContent = '✓ Watched'; row.appendChild(w); }
    row.addEventListener('click', () => playEpisode(vod.current, e, 0));
    row.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') playEpisode(vod.current, e, 0); });
    box.appendChild(row);
  }
}

// ---------------- the movie player ----------------

const vv = $('vodVideo');
let saveTimer = 0;

function playMovie(it, from) {
  const s = svc();
  play({ item: it, ep: null, key: itemKey(it), url: `${baseOf(s.server)}/movie/${encodeURIComponent(s.user)}/${encodeURIComponent(s.pass)}/${it.id}.${it.ext || 'mp4'}`, label: it.name }, from);
}
function playEpisode(it, ep, from) {
  const s = svc();
  play({ item: it, ep, key: itemKey(it), url: `${baseOf(s.server)}/series/${encodeURIComponent(s.user)}/${encodeURIComponent(s.pass)}/${ep.id}.${ep.ext || 'mp4'}`,
    label: it.name + '  ·  S' + ep.season + ' E' + ep.num + (ep.title ? '  ' + ep.title : '') }, from);
}

function play(p, from) {
  if ($('detail').open) $('detail').close();
  if (window.stopLive) stopLive();
  vod.playing = p;
  $('vodPlayer').hidden = false; $('vodNow').textContent = p.label;
  $('vodNext').hidden = !nextEp();
  vodMsg('Loading…');
  vv.src = p.url;
  vv.onloadedmetadata = () => { if (from > 0 && from < vv.duration - 5) vv.currentTime = from; };
  vv.play().catch(() => {});
  try { vv.requestFullscreen && document.documentElement.requestFullscreen().catch(() => {}); } catch (_) {}
  clearInterval(saveTimer); saveTimer = setInterval(savePos, 10000);
}
function vodMsg(t) { $('vodMsg').textContent = t || ''; $('vodMsg').hidden = !t; }
vv.addEventListener('playing', () => vodMsg(''));
vv.addEventListener('waiting', () => vodMsg('Loading…'));
vv.addEventListener('error', () => {
  const e = vv.error && vv.error.code;
  vodMsg(e === 4 ? "This one won't play on a computer (its video or sound format isn't supported). Try another version of it." : "Couldn't play it: your provider didn't send the video. Try again in a moment.");
});

function savePos() {
  const p = vod.playing; if (!p || !vv.duration || !isFinite(vv.duration)) return;
  const all = resumeAll();
  const done = vv.currentTime > vv.duration * 0.95;
  if (p.ep) {
    const w = store.get(vodKey('watched'), {}); if (done) { w[p.ep.id] = 1; store.set(vodKey('watched'), w); }
    all[p.key] = { item: p.item, ep: { id: p.ep.id, season: p.ep.season, num: p.ep.num }, pos: done ? 0 : vv.currentTime, dur: vv.duration, at: Date.now() };
  } else if (done) delete all[p.key];
  else if (vv.currentTime > 30) all[p.key] = { item: p.item, pos: vv.currentTime, dur: vv.duration, at: Date.now() };
  const keys = Object.keys(all).sort((a, b) => all[b].at - all[a].at); // keep the newest 60
  keys.slice(60).forEach((k) => delete all[k]);
  store.set(vodKey('resume'), all);
}

function nextEp() {
  const p = vod.playing; if (!p || !p.ep) return null;
  const i = vod.queue.findIndex((e) => e.id === p.ep.id);
  return i >= 0 ? vod.queue[i + 1] || null : null;
}
vv.addEventListener('ended', () => {
  savePos();
  const n = nextEp();
  if (n) { vodMsg('Next episode…'); setTimeout(() => vod.playing && vod.playing.ep && playEpisode(vod.playing.item, n, 0), 2500); }
  else closePlayer();
});
$('vodNext').addEventListener('click', () => { const n = nextEp(); if (n) { savePos(); playEpisode(vod.playing.item, n, 0); } });

function closePlayer() {
  savePos(); clearInterval(saveTimer);
  vv.pause(); vv.removeAttribute('src'); try { vv.load(); } catch (_) {}
  $('vodPlayer').hidden = true; vodMsg('');
  if (document.fullscreenElement) document.exitFullscreen().catch(() => {});
  const it = vod.playing && vod.playing.item; vod.playing = null;
  if (vod.cat === '__continue') openCat('__continue', 'Continue watching');
  if (it) openDetail(it);
}
$('vodBack').addEventListener('click', closePlayer);

document.addEventListener('keydown', (e) => {
  if ($('vodPlayer').hidden) return;
  if (e.key === 'Escape' || e.key === 'Backspace') { e.preventDefault(); closePlayer(); }
  else if (e.key === ' ') { e.preventDefault(); vv.paused ? vv.play() : vv.pause(); }
  else if (e.key === 'ArrowLeft') { e.preventDefault(); vv.currentTime = Math.max(0, vv.currentTime - 10); }
  else if (e.key === 'ArrowRight') { e.preventDefault(); vv.currentTime = Math.min(vv.duration || 0, vv.currentTime + 30); }
  else if (e.key.toLowerCase() === 'f') { if (document.fullscreenElement) document.exitFullscreen(); else document.documentElement.requestFullscreen().catch(() => {}); }
  else if (e.key.toLowerCase() === 'm') vv.muted = !vv.muted;
  else if (e.key.toLowerCase() === 'n') $('vodNext').click();
}, true);
window.addEventListener('beforeunload', savePos);
