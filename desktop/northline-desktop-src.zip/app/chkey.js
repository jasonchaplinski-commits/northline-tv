// What a channel is, ignoring quality and country: "US: A&E Network FHD" → "us a&e" (and "a&e").
// The same rules as the Fire Stick app, so the laptop matches channels to guides the same way.
// Used by the window (app) and by the guide downloader (main.js), so it works as both.
(function (root) {
  'use strict';
  const countries = new Set(['us', 'usa', 'uk', 'gb', 'ca', 'can', 'au', 'aus', 'nz', 'ie', 'fr', 'de', 'es', 'it', 'mx', 'br', 'in', 'pk', 'ar', 'pt', 'nl', 'be', 'se', 'no', 'dk', 'fi', 'pl', 'tr', 'gr']);
  const quality = /\b(4k|uhd|2160p?|fhd|1080p?|full hd|hd|720p?|hq|sd|480p?|576p?|lq|hevc|h ?265|h ?264|raw|50 ?fps|60 ?fps|backup|alt|vip|multi ?audio)\b/g;
  const small = { 'ᴴ': 'h', 'ᴰ': 'd', 'ᵁ': 'u', 'ˢ': 's', 'ᶠ': 'f', 'ᴿ': 'r', 'ᴬ': 'a', 'ᵂ': 'w', 'ᵀ': 't' };

  function plain(name) {
    let out = '';
    for (const c of String(name || '').toLowerCase()) out += small[c] || (/[a-z0-9+&]/.test(c) ? c : ' ');
    return out.replace(/\s+/g, ' ').trim();
  }

  /** Event channels ("NFL 01: Bears at Lions", "PPV 03 |") carry the event in their name: the text after the label, or null. */
  function eventTitle(name) {
    name = String(name || '');
    const i = name.search(/[:|]/);
    if (i < 2 || i >= name.length - 2) return null;
    const label = name.slice(0, i).trim();
    if (!/\d/.test(label)) return null; // "US: A&E" is a normal channel
    if (name[i] === ':' && /\d/.test(name[i + 1] || '') && /\d/.test(name[i - 1] || '')) return null; // a time like 12:30
    const t = name.slice(i + 1).trim().replace(/^[|:\-–\s]+|[|:\-–\s]+$/g, '').trim();
    return !t || isNoEvent(t) ? null : t;
  }
  const noEvent = /\b(no\s*events?|off\s*air|no\s*live\s*events?|not\s*live|no\s*games?)\b/i;
  /** "NFL 04:" with nothing after it, or "PPV 02: NO EVENT": an event channel with nothing on. */
  function isNoEvent(name) { return noEvent.test(name) || /^[^:|]*\d[^:|]*[:|]\s*$/.test(String(name || '')); }

  function chKey(name) {
    if (eventTitle(name) !== null || isNoEvent(name)) return '';
    let n = plain(name), country = '';
    const first = n.split(' ')[0];
    if (countries.has(first) && n.includes(' ')) { country = first === 'usa' ? 'us' : first === 'gb' ? 'uk' : first === 'can' ? 'ca' : first === 'aus' ? 'au' : first; n = n.slice(first.length + 1); }
    n = n.replace(quality, ' ').replace(/\s+/g, ' ').trim();
    const last = n.split(' ').pop();
    if (!country && n.includes(' ') && countries.has(last)) { country = last === 'usa' ? 'us' : last; n = n.slice(0, -last.length - 1); }
    n = n.replace(/\s+(network|channel|tv network)$/, '');
    if (n.length < 2) return '';
    return country ? country + ' ' + n : n;
  }
  const bare = (k) => { const f = k.split(' ')[0]; return k.includes(' ') && countries.has(f) ? k.slice(f.length + 1) : null; };

  /** Every name a guide might use for this channel, best first: "us abc news", "abc news", "us abc news live", "abc news live". */
  function keysFor(name) {
    const k = chKey(name); if (!k) return [];
    const b = bare(k);
    return [k, b, k + ' live', b && b + ' live'].filter(Boolean);
  }
  /** Keys for a guide's own channel name; "A&E East" also counts as "A&E". */
  function guideKeys(displayName) {
    const k = chKey(displayName); if (!k) return [];
    const out = [k]; const b = bare(k); if (b) out.push(b);
    for (const x of out.slice()) { const y = x.replace(/\s+(east|eastern|e)$/, ''); if (y !== x && y.length >= 2) out.push(y); }
    return out;
  }

  const api = { chKey, keysFor, guideKeys, eventTitle, isNoEvent, plain };
  if (typeof module !== 'undefined' && module.exports) module.exports = api; else root.Names = api;
})(typeof window !== 'undefined' ? window : this);
