'use strict';
// The service status line under the service name: free, this laptop, or in use not by this laptop, with a
// small log of when the service was used while this laptop wasn't on it. The service only says how many
// screens are in use (never who or where), so that's all this shows. One tiny check every 5 minutes.

const useLogKey = (s) => 'useLog.' + baseOf(s.server).toLowerCase() + '|' + s.user;
const st = { info: null, at: 0, since: 0 };

/** Is this laptop using [s] right now (watching it, or recording from it)? */
function laptopOn(s) {
  const watching = s === svc() && state.playing && (mp || hls) && !state.alt;
  const altHere = state.alt && state.alt.s === s && (mp || hls);
  const rec = window.recUsingScreen && recUsingScreen(s);
  return { watching: !!(watching || altHere), rec: !!rec, n: (watching || altHere ? 1 : 0) + (rec ? 1 : 0) };
}

/** Takes a fresh "screens in use" answer (from the 5-minute check, Login details, or the player's own checks). */
function noteScreens(s, active, max) {
  if (!s || s !== svc()) return;
  st.info = { active: +active || 0, max: +max || 0 }; st.at = Date.now();
  const mine = laptopOn(s).n;
  let elsewhere = Math.max(0, st.info.active - mine);
  // just switched channels here: the service may still be counting this laptop's last channel, so don't blame anyone else
  st.settling = elsewhere > 0 && Date.now() - (state.lastStop || 0) < 45000;
  if (st.settling) elsewhere = 0;
  // the log: periods when the service was in use and not by this laptop
  const log = store.get(useLogKey(s), []);
  const now = Date.now(), last = log[log.length - 1];
  if (elsewhere > 0) {
    if (last && now - last.e < 7 * 60000) last.e = now; else log.push({ s: now, e: now });
    st.since = (log[log.length - 1] || {}).s || now;
  } else st.since = 0;
  const weekAgo = now - 7 * 86400e3;
  store.set(useLogKey(s), log.filter((x) => x.e > weekAgo).slice(-300));
  drawStatus();
}
window.noteScreens = noteScreens;
window.statusReset = () => { st.info = null; st.since = 0; drawStatus(); };

function drawStatus() {
  const el = $('svcStatus'); const s = svc();
  if (!el || !s || !st.info || !st.info.max) { if (el) el.hidden = true; return; }
  const name = s.name || s.server, { active, max } = st.info;
  const me = laptopOn(s);
  const elsewhere = st.settling ? 0 : Math.max(0, active - me.n);
  if (st.settling && !me.n) { el.className = 'svcStatus mine'; el.textContent = name + ': this laptop · switching channels'; el.hidden = false; return; }
  let cls, text;
  if (elsewhere > 0) {
    cls = 'busy';
    text = max === 1 ? name + ': in use, not by this laptop' : name + ': ' + active + ' of ' + max + ' screens in use' + (me.n ? ' (' + me.n + ' here)' : '');
    if (st.since) text += '\nsince ' + new Date(st.since).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
  } else if (me.n) {
    cls = 'mine';
    text = name + ': this laptop' + (me.watching && state.playing ? ' · ' + state.playing.name : me.rec ? ' · recording' : '');
  } else {
    cls = 'free';
    text = name + ': free · ' + active + ' of ' + max + ' screen' + (max === 1 ? '' : 's');
  }
  el.className = 'svcStatus ' + cls; el.textContent = text; el.hidden = false;
  el.title = 'Checked ' + new Date(st.at).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }) + '. ' + name + " only says how many screens are in use, not who or where. Click for today's log.";
}

async function checkNow() {
  const s = svc(); if (!s || $('main').hidden) return;
  const n = await screens(s);
  if (n && svc() === s) noteScreens(s, n.active, n.max);
}
setInterval(checkNow, 5 * 60000);
// the laptop starting or stopping a channel changes "this laptop" right away (no extra request)
setInterval(drawStatus, 5000);

// ---------------- the log, in Settings ----------------
function drawUseLog() {
  const box = $('useLog'); const s = svc(); if (!box || !s) return;
  const name = s.name || s.server;
  $('useLogTitle').textContent = name + ' · used while this laptop wasn’t on it';
  const log = store.get(useLogKey(s), []);
  box.innerHTML = '';
  const day0 = new Date(); day0.setHours(0, 0, 0, 0);
  for (let d = 0; d < 5; d++) {
    const from = day0.getTime() - d * 86400e3, to = from + 86400e3;
    const parts = log.filter((x) => x.e > from && x.s < to);
    const row = document.createElement('div'); row.className = 'useRow';
    const lab = document.createElement('span'); lab.className = 'useDay';
    lab.textContent = d === 0 ? 'Today' : d === 1 ? 'Yesterday' : new Date(from).toLocaleDateString(undefined, { weekday: 'short' });
    const bar = document.createElement('div'); bar.className = 'useBar';
    for (const x of parts) {
      const a = Math.max(x.s, from), b = Math.min(Math.max(x.e, x.s + 5 * 60000), to);
      const i = document.createElement('i'); i.style.left = ((a - from) / 864e5 * 100) + '%'; i.style.width = Math.max(0.6, (b - a) / 864e5 * 100) + '%';
      i.title = new Date(a).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }) + ' – ' + new Date(b).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
      bar.appendChild(i);
    }
    const txt = document.createElement('span'); txt.className = 'useTxt dim';
    txt.textContent = parts.length ? parts.map((x) => new Date(Math.max(x.s, from)).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }) + '–' + new Date(Math.min(Math.max(x.e, x.s + 5 * 60000), to)).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' })).join(', ') : '—';
    row.appendChild(lab); row.appendChild(bar); row.appendChild(txt); box.appendChild(row);
  }
}
$('settingsBtn').addEventListener('click', drawUseLog);
$('svcStatus').addEventListener('click', () => { $('settingsBtn').click(); setTimeout(() => $('useLogTitle').scrollIntoView({ block: 'start' }), 50); });
