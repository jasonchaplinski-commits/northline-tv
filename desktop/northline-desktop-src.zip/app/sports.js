'use strict';
// Games in the guide, like the Fire Stick app: event channels such as "NFL 01: Chicago Bears at Detroit Lions"
// get the real kickoff time from the public game schedule (ESPN), with LIVE and the score while it's on, a
// "Today" strip of the games your service carries, and "No game on this channel today" on empty ones.

const LEAGUES = [
  ['football/nfl', 'nfl', 3.5, '🏈'], ['football/college-football', 'cfb', 3.5, '🏈'],
  ['basketball/nba', 'nba', 2.5, '🏀'], ['basketball/wnba', 'wnba', 2.0, '🏀'],
  ['basketball/mens-college-basketball', 'cbb', 2.25, '🏀'], ['basketball/womens-college-basketball', 'wcbb', 2.0, '🏀'],
  ['hockey/nhl', 'nhl', 2.75, '🏒'], ['baseball/mlb', 'mlb', 3.0, '⚾'], ['soccer/usa.1', 'mls', 2.0, '⚽'],
];
const EMOJI = Object.fromEntries(LEAGUES.map((l) => [l[1], l[3]]));
const sports = { games: store.get('sports.games', []), at: store.get('sports.at', 0), live: new Map() };

// ---------------- teams ----------------
const SEP = /\s+(?:vs\.?|v\.?|at|@|x|-)\s+/i;
const TAIL = /\s*(?:\bon\s+\d{4}-\d{2}-\d{2}.*|\(.*|\[.*|\|.*|\bLIVE\b.*|\d{1,2}[:.]\d{2}.*|\d{1,2}\s*[AaPp]\.?[Mm].*)$/;
/** The two teams in "Chicago Bears at Detroit Lions 1:00 PM ET", or null. */
function teams(text) {
  const t = String(text || '').replace(/^\s*(?:EVENT\s*[·:-]\s*)/i, '').trim();
  const m = SEP.exec(t); if (!m) return null;
  const a = t.slice(0, m.index).split(':').pop().trim();
  const b = t.slice(m.index + m[0].length).replace(TAIL, '').trim();
  return a.length >= 3 && b.length >= 3 ? [a, b] : null;
}
const nick = (team) => String(team).toLowerCase().replace(/[^a-z0-9 ]/g, ' ').trim().split(/\s+/).pop() || '';
const pairKey = (a, b) => [nick(a), nick(b)].sort().join('|');
const cap = (s) => s.replace(/\b\w/g, (c) => c.toUpperCase());

// ---------------- the public schedule ----------------
function etDay(ms) { return new Intl.DateTimeFormat('en-CA', { timeZone: 'America/New_York', year: 'numeric', month: '2-digit', day: '2-digit' }).format(new Date(ms)).replace(/-/g, ''); }

function readBoard(o, lg, hours) {
  const out = [];
  for (const e of (o && o.events) || []) {
    const start = Date.parse(e.date); if (!start) continue;
    const comp = (e.competitions || [])[0]; if (!comp || !comp.competitors || comp.competitors.length !== 2) continue;
    const t = comp.competitors.slice().sort((x, y) => (x.homeAway === 'home') - (y.homeAway === 'home'));
    const names = t.map((c) => (c.team && c.team.displayName) || '');
    if (names.some((n) => !n)) continue;
    const nets = [...new Set([].concat(...(comp.broadcasts || []).map((b) => b.names || [])))];
    const st = (comp.status || e.status || {}).type || {};
    out.push({ k: pairKey(names[0], names[1]), s: start, e: start + hours * 3600e3, n: e.name || names[0] + ' at ' + names[1],
      short: cap(nick(names[0])) + ' at ' + cap(nick(names[1])), ab: t.map((c) => (c.team && c.team.abbreviation) || ''), lg, nets,
      state: st.state || 'pre', detail: st.shortDetail || '', score: t.map((c) => c.score || '0') });
  }
  return out;
}

async function loadSchedule(force) {
  if (!force && sports.games.length && Date.now() - sports.at < 3 * 3600e3) return;
  const now = Date.now();
  const days = [...new Set([-1, 0, 1, 2].map((d) => etDay(now + d * 86400e3)))];
  const all = [];
  await Promise.all(LEAGUES.flatMap(([path, lg, hours]) => days.map(async (d) => {
    const extra = path.includes('college') ? '&groups=50&limit=400' : '&limit=400';
    try {
      const r = await fetch(`https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard?dates=${d}${extra}`, { cache: 'no-store' });
      if (r.ok) all.push(...readBoard(await r.json(), lg, hours));
    } catch (_) {}
  })));
  if (!all.length) return;
  const seen = new Set();
  sports.games = all.filter((g) => !seen.has(g.k + g.s) && seen.add(g.k + g.s));
  sports.at = Date.now();
  store.set('sports.games', sports.games); store.set('sports.at', sports.at);
  for (const g of sports.games) if (g.state !== 'pre') sports.live.set(g.k + '@' + g.s, g);
}

// scores while games are on: only today's scoreboard, only for leagues with a game going, once a minute
async function refreshLive() {
  const now = Date.now();
  const on = sports.games.filter((g) => g.s - 600e3 <= now && now < g.e + 3600e3);
  const lgs = [...new Set(on.map((g) => g.lg))];
  if (!lgs.length) return;
  for (const [path, lg, hours] of LEAGUES) {
    if (!lgs.includes(lg)) continue;
    try {
      const r = await fetch(`https://site.api.espn.com/apis/site/v2/sports/${path}/scoreboard?dates=${etDay(now)}${path.includes('college') ? '&groups=50&limit=400' : '&limit=400'}`, { cache: 'no-store' });
      if (!r.ok) continue;
      for (const g of readBoard(await r.json(), lg, hours)) {
        sports.live.set(g.k + '@' + g.s, g);
        // a game that runs long keeps its slot going until it's final
        const mine = sports.games.find((x) => x.k === g.k && x.s === g.s);
        if (mine && g.state === 'in' && mine.e < now + 600e3) mine.e = now + 900e3;
        if (mine && g.state === 'post' && mine.e > now) mine.e = Math.max(now, mine.s + 3600e3);
      }
    } catch (_) {}
  }
  fillEvents(); redrawRows(); drawToday();
}
const liveOf = (g) => sports.live.get(g.k + '@' + g.s) || g;

// ---------------- the guide rows ----------------
const hm = (t) => new Date(t).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
function until(t) { const m = Math.max(0, Math.round((t - Date.now()) / 60000)); return m < 60 ? m + ' min' : Math.floor(m / 60) + 'h ' + (m % 60) + 'm'; }

/** The game an event channel's name is about: the one with those teams nearest to now. */
function gameFor(name) {
  const t = Names.eventTitle(name); if (!t) return null;
  const tm = teams(t); if (!tm) return null;
  const k = pairKey(tm[0], tm[1]); const now = Date.now();
  return sports.games.filter((g) => g.k === k && g.e > now - 3600e3).sort((a, b) => Math.abs(a.s - now) - Math.abs(b.s - now))[0] || null;
}

/** Shows for one game channel: "Next: … · 1:30 PM" until kickoff, the game, then "Game over". */
function gameShows(g) {
  const now = Date.now(), from = now - 3 * 3600e3, to = now + 30 * 3600e3, e = EMOJI[g.lg] || '🏆';
  const name = e + ' ' + g.short;
  const l = [];
  if (g.s > from) l.push({ start: from, stop: g.s, title: 'Next: ' + name + ' · ' + hm(g.s), sub: 'Starts in ' + until(g.s) + (g.nets.length ? ' · ' + g.nets.join(', ') : ''), pre: true, game: g });
  l.push({ start: g.s, stop: g.e, title: name, sub: hm(g.s) + ' – about ' + hm(g.e) + (g.nets.length ? ' · ' + g.nets.join(', ') : ''), game: g, desc: g.n });
  if (g.e < to) l.push({ start: g.e, stop: to, title: 'Game over', sub: g.n, post: true, game: g });
  return l;
}
function emptyShows() { const now = Date.now(); return [{ start: now - 3 * 3600e3, stop: now + 30 * 3600e3, title: 'No game on this channel today', none: true }]; }

/** Puts the games into the guide for every event channel the provider left empty. */
function fillEvents() {
  if (!state.streams.length) return;
  sports.byCh = new Map();
  for (const ch of state.streams) {
    if (ch.fill && ch.fill !== 'game') continue; // filled by the backup guide
    const own = state.epg.get(ch.id);
    if (own && own.length && !ch.fill) continue; // the provider's own guide wins
    const g = gameFor(ch.name);
    if (g) { state.epg.set(ch.id, gameShows(g)); ch.fill = 'game'; sports.byCh.set(ch.id, g); }
    else if (Names.isNoEvent(ch.name)) { state.epg.set(ch.id, emptyShows()); ch.fill = 'game'; }
    else if (Names.eventTitle(ch.name)) {
      // an event the game schedule doesn't know (a race, a fight, soccer abroad): show what the channel name says
      const now = Date.now();
      state.epg.set(ch.id, [{ start: now - 3 * 3600e3, stop: now + 30 * 3600e3, title: Names.eventTitle(ch.name) }]); ch.fill = 'game';
    }
  }
}
function redrawRows() { document.querySelectorAll('.ch').forEach((r) => drawProgs(r.querySelector('.progs'), state.epg.get(r._ch.id))); if (state.playing) showInfo(state.playing); }

/** How a guide block shows a game: LIVE and the score while it's on. */
window.gameBlock = function (d, e) {
  if (!e.game && !e.none) return false;
  const g = e.game ? liveOf(e.game) : null;
  d.classList.add(e.none ? 'nogame' : e.pre ? 'pregame' : e.post ? 'postgame' : 'game');
  d.textContent = '';
  const top = document.createElement('span'); top.className = 'gt'; top.textContent = e.title;
  if (g && !e.pre && !e.post && g.state === 'in') { const b = document.createElement('i'); b.className = 'liveTag'; b.textContent = 'LIVE'; top.appendChild(b); }
  d.appendChild(top);
  let sub = e.sub || '';
  if (g && !e.pre && g.state !== 'pre') sub = g.ab[0] + ' ' + g.score[0] + ' – ' + g.ab[1] + ' ' + g.score[1] + ' · ' + (g.detail || '');
  else if (e.pre && e.game) sub = 'Starts in ' + until(e.game.s) + (e.game.nets.length ? ' · ' + e.game.nets.join(', ') : '');
  if (sub) { const s = document.createElement('small'); s.textContent = sub; d.appendChild(s); }
  return true;
};

// ---------------- the Today strip ----------------
function todaysGames() {
  const now = Date.now();
  const end = new Date(); end.setHours(24, 0, 0, 0);
  const out = [];
  if (!sports.byCh) return out;
  const seen = new Set();
  for (const [chId, g] of sports.byCh) {
    if (seen.has(g.k + g.s)) continue;
    if (!(g.s < end.getTime() && g.e > now - 600e3)) continue;
    const ch = state.streams.find((x) => x.id === chId); if (!ch) continue;
    seen.add(g.k + g.s); out.push({ g: liveOf(g), ch });
  }
  return out.sort((a, b) => (b.g.state === 'in') - (a.g.state === 'in') || a.g.s - b.g.s);
}
function drawToday() {
  const box = $('today'); if (!box) return;
  const list = (window.nlMode && window.nlMode !== 'live') ? [] : todaysGames();
  box.hidden = !list.length; box.innerHTML = '';
  if (!list.length) return;
  const lab = document.createElement('span'); lab.className = 'todayLab'; lab.textContent = 'TODAY'; box.appendChild(lab);
  for (const { g, ch } of list) {
    const c = document.createElement('div'); c.className = 'gameCard' + (g.state === 'in' ? ' live' : ''); c.tabIndex = 0; c.title = 'Watch ' + g.n + ' on ' + ch.name;
    const top = document.createElement('div'); top.className = 'gcTop';
    const when = document.createElement('span');
    if (g.state === 'in') { when.className = 'liveTag'; when.textContent = '● LIVE · ' + (g.detail || ''); }
    else if (g.state === 'post') { when.className = 'dim'; when.textContent = g.detail || 'Final'; }
    else { when.className = 'accent'; when.textContent = hm(g.s) + ' · in ' + until(g.s); }
    const where = document.createElement('span'); where.className = 'dim'; where.textContent = (g.nets[0] ? g.nets[0] + ' · ' : '') + ch.name.split(':')[0];
    top.appendChild(when); top.appendChild(where);
    const mid = document.createElement('div'); mid.className = 'gcTeams'; mid.textContent = (EMOJI[g.lg] || '') + ' ' + g.short;
    const bot = document.createElement('div'); bot.className = 'gcBot';
    if (g.state !== 'pre') bot.textContent = g.ab[0] + ' ' + g.score[0] + ' – ' + g.ab[1] + ' ' + g.score[1];
    else {
      const rb = document.createElement('button'); rb.className = 'ghost small'; rb.textContent = '⏺ Record';
      rb.addEventListener('click', (ev) => { ev.stopPropagation(); if (window.recSchedule) { recSchedule(svc(), ch, { title: g.short, start: g.s, stop: g.e }); rb.textContent = '🔴 Set to record'; } });
      bot.appendChild(rb);
    }
    c.appendChild(top); c.appendChild(mid); c.appendChild(bot);
    c.addEventListener('click', () => select(ch));
    c.addEventListener('keydown', (ev) => { if (ev.key === 'Enter') select(ch); });
    box.appendChild(c);
  }
}
window.drawToday = drawToday;

// ---------------- game counts on the groups ----------------
function groupCounts() {
  const end = new Date(); end.setHours(24, 0, 0, 0);
  const n = new Map();
  if (sports.byCh) for (const [chId, g] of sports.byCh) {
    if (!(g.s < end.getTime() && g.e > Date.now())) continue;
    const ch = state.streams.find((x) => x.id === chId); if (!ch) continue;
    const c = n.get(ch.cat) || { games: new Set(), lg: g.lg }; c.games.add(g.k + g.s); n.set(ch.cat, c);
  }
  document.querySelectorAll('#groups button').forEach((b) => {
    const old = b.querySelector('.gcount'); if (old) old.remove();
    const c = n.get(b.dataset.id); if (!c) return;
    const sp = document.createElement('span'); sp.className = 'gcount'; sp.textContent = '  ·  ' + (EMOJI[c.lg] || '🏆') + ' ' + c.games.size + ' today';
    b.appendChild(sp);
  });
}

// ---------------- when things load ----------------
async function sportsFill() {
  await loadSchedule(false);
  fillEvents(); redrawRows(); drawToday(); groupCounts();
}
window.sportsFill = sportsFill;
window.sportsAfterGroups = () => { groupCounts(); };
setInterval(() => { if (!$('main').hidden) refreshLive(); }, 60000);
setInterval(async () => { if ($('main').hidden) return; await loadSchedule(false); fillEvents(); redrawRows(); drawToday(); groupCounts(); }, 30 * 60000);
// keep "in 3h 40m" fresh
setInterval(() => { if (!$('main').hidden) drawToday(); }, 60000);
