'use strict';
// Recording to a folder: ⏺ in the player (or R) records what's on, right-click a show in the guide to record it
// (or every show with those words), and it all lands in your recordings folder as video files.

const RECAPI = window.northline && window.northline.rec;
const rec = {
  list: [],
  sched: store.get('recSched', []),   // { svc, chId, chName, title, start, stop, done }
  rules: store.get('recRules', []),   // { svc, chId (or '' = any channel), chName, match }
  dir: store.get('recDir', ''),
  early: store.get('recEarly', 2),
  late: store.get('recLate', 10),
};
const svcKey = (s) => baseOf(s.server).toLowerCase() + '|' + s.user;
const svcByKey = (k) => state.services.find((s) => svcKey(s) === k);
const saveSched = () => store.set('recSched', rec.sched.map(({ svc, chId, chName, title, start, stop, done }) => ({ svc, chId, chName, title, start, stop, done })));
const saveRules = () => store.set('recRules', rec.rules);
const fmtTime = (t) => new Date(t).toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' });
const fmtDay = (t) => new Date(t).toLocaleDateString(undefined, { weekday: 'short', month: 'short', day: 'numeric' });
const hms = (ms) => { const t = Math.max(0, Math.floor(ms / 1000)); return Math.floor(t / 3600) + ':' + String(Math.floor(t / 60) % 60).padStart(2, '0') + ':' + String(t % 60).padStart(2, '0'); };
const gb = (b) => b >= 1e9 ? (b / 1e9).toFixed(1) + ' GB' : Math.max(0, Math.round(b / 1e6)) + ' MB';

/** Is a recording using this service right now (matters on one-screen services)? */
function recUsingScreen(s) { const k = svcKey(s) + '#'; return rec.list.some((j) => j.id.startsWith(k)); }
window.recUsingScreen = recUsingScreen;
const recordingOf = (s, chId) => rec.list.find((j) => j.id.startsWith(svcKey(s) + '#' + chId + '#'));

/** Starts recording [ch] of service [s] until [until] (ms). */
async function recStart(s, ch, title, until) {
  if (!RECAPI) { alert('Recording works in the Northline TV app for Windows and Mac.'); return; }
  if (recordingOf(s, ch.id)) return;
  // a one-screen service can't record and play at once: the recording takes the screen
  const one = s === svc() && state.maxConn === 1 && !state.alt;
  if (one) stopPlayer();
  const go = () => RECAPI.start({ id: svcKey(s) + '#' + ch.id + '#' + Date.now(), url: streamUrl(s, ch.id, 'ts'), dir: rec.dir || undefined, title, channel: ch.name, until });
  if (one) { await new Promise((ok) => setTimeout(ok, 1200)); await go(); if (state.playing) start(state.playing, state.format); }
  else await go();
}

function nowShow(ch) { const now = Date.now(); return (state.epg.get(ch.id) || []).find((e) => e.start <= now && e.stop > now); }

/** ⏺ / R: record the channel you're watching until its show ends (or stop if it's already recording). */
function recToggle() {
  const ch = state.playing; if (!ch) return;
  const s = state.alt ? state.alt.s : svc();
  const id = state.alt ? state.alt.id : ch.id;
  const on = recordingOf(s, id);
  if (on) { RECAPI.stop(on.id); return; }
  const e = nowShow(ch);
  recStart(s, { id, name: ch.name }, e ? e.title : ch.name, e ? e.stop + rec.late * 60000 : Date.now() + 4 * 3600e3);
}

// ---------------- scheduled recordings ----------------

const findSched = (k, chId, start) => rec.sched.find((x) => x.svc === k && x.chId === chId && x.start === start);
function recMarked(ch, e) { const s = svc(); return !!(s && ch && findSched(svcKey(s), ch.id, e.start)); }
window.recMarked = recMarked;

function schedule(s, ch, e) {
  const k = svcKey(s);
  // a one-screen service can only record one thing at a time
  if (s === svc() && state.maxConn === 1) {
    const clash = rec.sched.find((x) => x.svc === k && x.start < e.stop && e.start < x.stop && !(x.chId === ch.id && x.start === e.start));
    if (clash && !confirm((s.name || s.server) + ' allows 1 screen and is already recording “' + clash.title + '” then.\n\nRecord “' + e.title + '” anyway? It starts when the other recording finishes.')) return;
  }
  if (!findSched(k, ch.id, e.start)) rec.sched.push({ svc: k, chId: ch.id, chName: ch.name, title: e.title, start: e.start, stop: e.stop });
  saveSched(); redrawMarks(); recTick();
}
function unschedule(k, chId, start) {
  const x = findSched(k, chId, start); if (!x) return;
  rec.sched = rec.sched.filter((y) => y !== x); saveSched();
  const on = rec.list.find((j) => j.id.startsWith(k + '#' + chId + '#')); if (on && x.done) RECAPI.stop(on.id);
  redrawMarks();
}

function recTick() {
  const now = Date.now(); let changed = false;
  for (const e of rec.sched) {
    if (e.done) continue;
    if (now >= e.start - rec.early * 60000 && now < e.stop + rec.late * 60000) {
      e.done = true; changed = true;
      const s = svcByKey(e.svc);
      if (s) recStart(s, { id: e.chId, name: e.chName }, e.title, e.stop + rec.late * 60000);
    }
  }
  const keep = rec.sched.filter((e) => now < e.stop + rec.late * 60000 + 60000);
  if (keep.length !== rec.sched.length) { rec.sched = keep; changed = true; }
  if (changed) { saveSched(); redrawMarks(); }
}
setInterval(recTick, 15000);

// "every show with these words": checks the guide for the next day and adds what it finds
async function recRulesTick() {
  const now = Date.now(); let added = 0;
  for (const rule of rec.rules) {
    const s = svcByKey(rule.svc); if (!s) continue;
    let chans = [];
    try {
      if (s === svc()) {
        chans = state.streams.filter((x) => !rule.chId || x.id === rule.chId).map((x) => ({ id: x.id, name: x.name, l: state.epg.get(x.id) || [] }));
      } else if (window.northline && northline.guide) {
        const k = baseOf(s.server) + '|' + s.user;
        let list = otherLists.get(k);
        if (!list) { list = await api(s, 'get_live_streams').catch(() => []); otherLists.set(k, Array.isArray(list) ? list : []); list = otherLists.get(k); }
        const st = list.map((x) => ({ id: String(x.stream_id), name: String(x.name || '').trim(), epg: String(x.epg_channel_id || '').trim() })).filter((x) => x.epg && (!rule.chId || x.id === rule.chId));
        const data = await northline.guide({ base: baseOf(s.server), user: s.user, pass: s.pass, ids: [...new Set(st.map((x) => x.epg))] });
        chans = st.map((x) => ({ id: x.id, name: x.name, l: data[x.epg.toLowerCase()] || [] }));
      }
    } catch (_) { continue; }
    const words = rule.match.toLowerCase();
    for (const c of chans) for (const e of c.l) {
      if (e.stop < now || e.start > now + 26 * 3600e3 || !e.title.toLowerCase().includes(words)) continue;
      if (findSched(rule.svc, c.id, e.start)) continue;
      if (rec.sched.some((x) => x.svc === rule.svc && x.title === e.title && x.start === e.start)) continue; // same game on two channels: once
      rec.sched.push({ svc: rule.svc, chId: c.id, chName: c.name, title: e.title, start: e.start, stop: e.stop }); added++;
    }
  }
  if (added) { saveSched(); redrawMarks(); recTick(); }
}
window.recRulesTick = recRulesTick;
setInterval(recRulesTick, 30 * 60000);

function redrawMarks() {
  document.querySelectorAll('.ch').forEach((r) => drawProgs(r.querySelector('.progs'), state.epg.get(r._ch.id)));
  if ($('settings').open) drawRecSettings();
}

// ---------------- the player: ⏺ button and the REC timer ----------------

function recUi() {
  const ch = state.playing;
  const s = state.alt ? state.alt.s : svc();
  const j = ch && s && recordingOf(s, state.alt ? state.alt.id : ch.id);
  $('recBtn').classList.toggle('on', !!j);
  $('recBtn').title = j ? 'Stop recording (R)' : 'Record this show (R)';
  $('recTag').hidden = !j;
  if (j) $('recTag').textContent = (j.state === 'reconnecting' ? (j.bytes ? '⏺ REC · reconnecting… ' : '⏺ waiting for the screen… ') : '⏺ REC ') + hms(Date.now() - j.started) + (j.until ? '  ·  until ' + fmtTime(j.until) : '');
  const n = rec.list.length;
  $('recPill').hidden = !n;
  $('recPill').textContent = '⏺ Recording ' + (n === 1 ? (rec.list[0].title || '1 show') : n + ' shows');
}
setInterval(recUi, 1000);
$('recBtn').addEventListener('click', recToggle);
$('recPill').addEventListener('click', () => { $('settingsBtn').click(); setTimeout(() => $('recSection').scrollIntoView({ block: 'start' }), 50); });
document.addEventListener('keydown', (e) => {
  if (e.key.toLowerCase() !== 'r' || e.ctrlKey || e.metaKey || e.altKey) return;
  const typing = /^(INPUT|SELECT|TEXTAREA)$/.test(document.activeElement && document.activeElement.tagName);
  if (typing || $('main').hidden || $('settings').open || (window.nlMode && window.nlMode !== 'live')) return;
  recToggle();
});

if (RECAPI) {
  RECAPI.onChange((list) => { rec.list = list; recUi(); if ($('settings').open) drawRecSettings(); });
  RECAPI.list().then((l) => { rec.list = l; recUi(); });
}

// ---------------- right-click in the guide ----------------

const menu = $('ctxMenu');
function closeMenu() { menu.hidden = true; }
document.addEventListener('click', closeMenu);
document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeMenu(); });
$('list').addEventListener('scroll', closeMenu);
$('list').addEventListener('contextmenu', (ev) => {
  const r = ev.target.closest('.ch'); if (!r) return;
  ev.preventDefault();
  const ch = r._ch, s = svc(), k = svcKey(s);
  const pe = ev.target.closest('.prog');
  const e = pe && pe._e;
  const items = [];
  items.push(['▶  Watch', () => select(ch)]);
  if (e) {
    const now = Date.now();
    if (findSched(k, ch.id, e.start)) items.push(['✕  Cancel recording “' + e.title + '”', () => unschedule(k, ch.id, e.start)]);
    else if (e.stop > now) items.push(['⏺  Record “' + e.title + '”', () => schedule(s, ch, e)]);
    items.push(['⏺  Record every show called…', () => ruleDialog(s, ch, e.title)]);
  } else {
    const on = recordingOf(s, ch.id);
    if (on) items.push(['⏹  Stop recording', () => RECAPI.stop(on.id)]);
    else { const cur = nowShow(ch); items.push(['⏺  Record now', () => recStart(s, ch, cur ? cur.title : ch.name, cur ? cur.stop + rec.late * 60000 : Date.now() + 4 * 3600e3)]); }
    items.push(['⏺  Record every show called…', () => ruleDialog(s, ch, (nowShow(ch) || {}).title || '')]);
  }
  menu.innerHTML = '';
  if (e) { const h = document.createElement('div'); h.className = 'ctxHead'; h.textContent = e.title + '  ·  ' + fmtTime(e.start) + ' – ' + fmtTime(e.stop); menu.appendChild(h); }
  for (const [label, f] of items) { const b = document.createElement('button'); b.textContent = label; b.addEventListener('click', () => { closeMenu(); f(); }); menu.appendChild(b); }
  menu.hidden = false;
  const w = menu.offsetWidth, h = menu.offsetHeight;
  menu.style.left = Math.min(ev.clientX, innerWidth - w - 8) + 'px';
  menu.style.top = Math.min(ev.clientY, innerHeight - h - 8) + 'px';
});

function ruleDialog(s, ch, title) {
  const d = $('ruleDlg');
  $('ruleWords').value = title || '';
  $('ruleCh').textContent = ch.name;
  $('ruleAny').checked = false;
  d.showModal(); $('ruleWords').focus(); $('ruleWords').select();
  $('ruleSave').onclick = (ev) => {
    ev.preventDefault();
    const match = $('ruleWords').value.trim(); if (!match) return;
    rec.rules.push({ svc: svcKey(s), chId: $('ruleAny').checked ? '' : ch.id, chName: $('ruleAny').checked ? '' : ch.name, match });
    saveRules(); d.close(); recRulesTick();
  };
}
$('ruleCancel').addEventListener('click', () => $('ruleDlg').close());

// ---------------- Settings › Recordings ----------------

async function drawRecSettings() {
  const dirNow = rec.dir || (RECAPI ? await RECAPI.defaultFolder() : '');
  $('recDir').textContent = dirNow;
  $('recEarly').value = String(rec.early); $('recLate').value = String(rec.late);
  if (RECAPI) RECAPI.freeSpace(rec.dir || undefined).then((b) => { $('recFree').textContent = b > 0 ? gb(b) + ' free · about ' + Math.floor(b / 1.6e9) + ' hours of TV' : ''; });
  const box = $('recList'); box.innerHTML = '';
  const row = (text, sub, btn, f) => {
    const r = document.createElement('div'); r.className = 'svcRow';
    const t = document.createElement('span'); t.textContent = text; if (sub) { const sm = document.createElement('small'); sm.className = 'dim'; sm.textContent = '  ' + sub; t.appendChild(sm); }
    r.appendChild(t);
    if (btn) { const b = document.createElement('button'); b.className = 'ghost small'; b.textContent = btn; b.addEventListener('click', f); r.appendChild(b); }
    box.appendChild(r);
  };
  const head = (t) => { const h = document.createElement('div'); h.className = 'dim small recHead'; h.textContent = t; box.appendChild(h); };
  if (rec.list.length) { head('Recording now'); for (const j of rec.list) row('⏺ ' + j.title + ' · ' + j.channel, hms(Date.now() - j.started) + ' · ' + gb(j.bytes) + (j.state === 'reconnecting' ? (j.bytes ? ' · reconnecting…' : ' · waiting for the screen (starts when it frees)') : ''), 'Stop', () => RECAPI.stop(j.id)); }
  const coming = rec.sched.filter((x) => !x.done).sort((a, b) => a.start - b.start);
  if (coming.length) { head('Coming up'); for (const x of coming.slice(0, 30)) row(x.title + ' · ' + x.chName, fmtDay(x.start) + ' ' + fmtTime(x.start) + ' – ' + fmtTime(x.stop), 'Cancel', () => { unschedule(x.svc, x.chId, x.start); drawRecSettings(); }); }
  if (rec.rules.length) { head('Record every show called'); rec.rules.forEach((r, i) => { const s = svcByKey(r.svc); row('“' + r.match + '”', (r.chName || 'any channel') + ' · ' + (s ? s.name || s.server : 'removed service'), 'Remove', () => { rec.rules.splice(i, 1); saveRules(); drawRecSettings(); }); }); }
  if (!rec.list.length && !coming.length && !rec.rules.length) { const p = document.createElement('p'); p.className = 'dim small'; p.textContent = 'Nothing yet. Press ⏺ while watching, or right-click a show in the guide.'; box.appendChild(p); }
}
$('settingsBtn').addEventListener('click', drawRecSettings);
$('recChoose').addEventListener('click', async () => { if (!RECAPI) return; const d = await RECAPI.chooseFolder(rec.dir || undefined); if (d) { rec.dir = d; store.set('recDir', d); drawRecSettings(); } });
$('recOpen').addEventListener('click', () => RECAPI && RECAPI.openFolder(rec.dir || undefined));
$('recEarly').addEventListener('change', (e) => { rec.early = +e.target.value; store.set('recEarly', rec.early); });
$('recLate').addEventListener('change', (e) => { rec.late = +e.target.value; store.set('recLate', rec.late); });

recTick();
