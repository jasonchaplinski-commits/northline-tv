'use strict';
// Filling channels your provider's guide leaves empty, in the same order as the Fire Stick app:
// 1) your other services' guides (same channel, matched by name), 2) the free backup guide (or your own link).

const BACKUP = {
  us: 'https://epgshare01.online/epgshare01/epg_ripper_US2.xml.gz',
  sports: 'https://epgshare01.online/epgshare01/epg_ripper_US_SPORTS1.xml.gz',
};
const guideSet = {
  other: store.get('useOtherGuides', true),
  backup: store.get('backupGuide', 'us'),   // 'us' | 'sports' | 'custom' | 'off'
  url: store.get('backupGuideUrl', ''),
};
const backupUrl = () => guideSet.backup === 'off' ? '' : guideSet.backup === 'custom' ? guideSet.url : BACKUP[guideSet.backup] || '';

/** Channels with nothing in the guide (or nothing after the next hour), not counting event channels. */
function emptyChannels() {
  const soon = Date.now() + 3600e3;
  return state.streams.filter((ch) => {
    if (ch.fill === 'game' || Names.eventTitle(ch.name) !== null || Names.isNoEvent(ch.name)) return false;
    const l = state.epg.get(ch.id);
    return !l || !l.length || l[l.length - 1].stop < soon;
  });
}

let fillRun = 0;
async function fillGaps(s, force) {
  const run = ++fillRun;
  state.guideLoading = true;
  try { return await fillGapsNow(s, force, run); } finally { if (run === fillRun) state.guideLoading = false; }
}
async function fillGapsNow(s, force, run) {
  const alive = () => run === fillRun && svc() === s;
  let missing = emptyChannels();
  if (state.streams.length > 15000) missing = missing.slice(0, 4000); // huge lineups: keep it small
  if (!missing.length) return;
  let fromOther = 0, fromBackup = 0;
  const put = (ch, l) => { state.epg.set(ch.id, l); ch.fill = 'extra'; };

  // 1) your other services
  if (guideSet.other && window.northline && northline.guide) {
    for (const o of state.services) {
      if (o === s || !missing.length) continue;
      try {
        const k = baseOf(o.server) + '|' + o.user;
        let list = otherLists.get(k);
        if (!list) { list = await api(o, 'get_live_streams').catch(() => []); otherLists.set(k, Array.isArray(list) ? list : []); list = otherLists.get(k); }
        if (!alive()) return;
        const byKey = new Map();
        for (const x of list) { const e = String(x.epg_channel_id || '').trim(); if (!e) continue; for (const key of Names.keysFor(x.name)) if (!byKey.has(key)) byKey.set(key, e); }
        const want = new Map();
        for (const ch of missing) { const e = Names.keysFor(ch.name).map((key) => byKey.get(key)).find(Boolean); if (e) want.set(ch.id, e); }
        if (!want.size) continue;
        const data = await northline.guide({ base: baseOf(o.server), user: o.user, pass: o.pass, ids: [...new Set(want.values())] });
        if (!alive()) return;
        for (const ch of missing) { const e = want.get(ch.id); const l = e && data[e.toLowerCase()]; if (l && l.length) { put(ch, l); fromOther++; } }
        missing = missing.filter((ch) => ch.fill !== 'extra');
      } catch (_) {}
    }
  }

  // 2) the backup guide
  const url = backupUrl();
  if (missing.length && url && window.northline && northline.backupGuide) {
    store.set('guideStatus', '… filling empty channels from the backup guide');
    showGuideStatus();
    try {
      const keys = [...new Set(missing.flatMap((ch) => Names.keysFor(ch.name)))];
      const { index, data } = await northline.backupGuide({ url, keys, force: !!force });
      if (!alive()) return;
      for (const ch of missing) { const id = Names.keysFor(ch.name).map((key) => index[key]).find(Boolean); const l = id && data[id]; if (l && l.length) { put(ch, l); fromBackup++; } }
      store.set('guideStatus', '✓ ' + new Date().toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }) + ' · filled ' + (fromOther + fromBackup) + ' channels' + (fromOther ? ' (' + fromOther + ' from your other services)' : ''));
    } catch (ex) {
      store.set('guideStatus', '✗ ' + new Date().toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }) + ' · backup guide: ' + (ex && ex.message || ex));
    }
  } else if (fromOther) store.set('guideStatus', '✓ ' + new Date().toLocaleTimeString(undefined, { hour: 'numeric', minute: '2-digit' }) + ' · filled ' + fromOther + ' channels from your other services');
  showGuideStatus();
  if (!alive() || !(fromOther + fromBackup)) return;
  document.querySelectorAll('.ch').forEach((r) => drawProgs(r.querySelector('.progs'), state.epg.get(r._ch.id)));
  if (state.playing) showInfo(state.playing);
  if (window.recRulesTick) recRulesTick();
}
window.fillGaps = fillGaps;

// ---------------- Settings › TV guide ----------------

function showGuideStatus() { const el = $('guideStatus'); if (el) el.textContent = store.get('guideStatus', 'Runs with the next guide update.'); }
function drawGuideSettings() {
  $('useOther').checked = guideSet.other;
  $('backupSel').value = guideSet.backup;
  $('backupUrl').value = guideSet.url;
  $('backupUrl').hidden = guideSet.backup !== 'custom';
  showGuideStatus();
}
$('settingsBtn').addEventListener('click', drawGuideSettings);
$('useOther').addEventListener('change', (e) => { guideSet.other = e.target.checked; store.set('useOtherGuides', guideSet.other); });
$('backupSel').addEventListener('change', (e) => { guideSet.backup = e.target.value; store.set('backupGuide', guideSet.backup); $('backupUrl').hidden = guideSet.backup !== 'custom'; if (guideSet.backup === 'custom') $('backupUrl').focus(); });
$('backupUrl').addEventListener('change', (e) => { guideSet.url = e.target.value.trim(); store.set('backupGuideUrl', guideSet.url); });
$('guideNow').addEventListener('click', () => { const s = svc(); if (!s) return; $('guideStatus').textContent = '… updating the guide'; loadGuide(s, true); });
