// Recording live TV to a folder: the stream is saved as it arrives (a .ts video file that plays in VLC,
// Windows Media Player, QuickTime with VLC, etc). If the stream drops, it reconnects and keeps adding to the same file.
'use strict';
const fs = require('fs');
const path = require('path');

/** A file name Windows and Mac both accept: "Suns at Rockets · NBA TV · Nov 25 2026.ts". */
function fileName(title, channel, when = new Date()) {
  const clean = (s) => String(s || '').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 80);
  const d = when.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' }).replace(',', '');
  const t = when.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' }).replace(':', '.').replace(/\s/g, '');
  const parts = [clean(title), clean(channel)].filter(Boolean);
  if (parts.length > 1 && parts[0].toLowerCase() === parts[1].toLowerCase()) parts.pop();
  return parts.concat([d + ' ' + t]).join(' · ') + '.ts';
}

/** A free name in [dir]: adds (2), (3)… when the name is taken. */
function freeName(dir, name) {
  let p = path.join(dir, name), n = 2;
  while (fs.existsSync(p)) p = path.join(dir, name.replace(/\.ts$/, ` (${n++}).ts`));
  return p;
}

class Recorder {
  constructor(fetchFn, onChange, opts = {}) {
    this.fetch = fetchFn; this.onChange = onChange || (() => {}); this.ua = opts.ua || 'NorthlineTV/1.0 (Android TV)';
    this.retryMs = opts.retryMs || 3000;
    this.jobs = new Map();
  }
  list() {
    return [...this.jobs.values()].map((j) => ({ id: j.id, title: j.title, channel: j.channel, file: j.file, bytes: j.bytes, started: j.started, until: j.until, state: j.state, note: j.note }));
  }
  /** Starts recording [url] into [dir]; stops at [until] (ms, 0 = until stopped). */
  start({ id, url, dir, title, channel, until = 0 }) {
    if (this.jobs.has(id)) return this.jobs.get(id).file;
    fs.mkdirSync(dir, { recursive: true });
    const file = freeName(dir, fileName(title, channel));
    const j = { id, url, file, title, channel, until, bytes: 0, started: Date.now(), state: 'recording', note: '', ctl: null, out: fs.createWriteStream(file), timer: null };
    this.jobs.set(id, j);
    if (until) j.timer = setTimeout(() => this.stop(id), Math.max(1000, until - Date.now()));
    this._pull(j);
    this.onChange();
    return file;
  }
  async _pull(j) {
    while (this.jobs.get(j.id) === j && j.state !== 'done') {
      j.ctl = new AbortController();
      try {
        const r = await this.fetch(j.url, { headers: { 'User-Agent': this.ua }, signal: j.ctl.signal });
        if (!r.ok) throw new Error('The server answered ' + r.status);
        j.state = 'recording'; j.note = ''; this.onChange();
        const rd = r.body.getReader();
        for (;;) {
          const { done, value } = await rd.read();
          if (done) break;
          j.bytes += value.length;
          if (!j.out.write(Buffer.from(value))) await new Promise((ok) => j.out.once('drain', ok));
        }
        throw new Error('The stream ended');
      } catch (e) {
        if (j.state === 'done') break;
        j.state = 'reconnecting'; j.note = String(e && e.message || e); this.onChange();
        await new Promise((ok) => setTimeout(ok, this.retryMs));
      }
    }
  }
  stop(id) {
    const j = this.jobs.get(id); if (!j) return null;
    j.state = 'done'; clearTimeout(j.timer);
    try { j.ctl && j.ctl.abort(); } catch (_) {}
    j.out.end();
    this.jobs.delete(id);
    // nothing arrived at all: don't leave an empty file behind
    if (!j.bytes) j.out.on('close', () => { try { fs.unlinkSync(j.file); } catch (_) {} });
    this.onChange();
    return j.file;
  }
  stopAll() { for (const id of [...this.jobs.keys()]) this.stop(id); }
}

module.exports = { Recorder, fileName, freeName };
