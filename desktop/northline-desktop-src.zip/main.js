// Northline TV for Windows and Mac: one window running the app in app/.
// The page talks to your TV service directly (IPTV servers don't allow browser pages, so web security is off
// for this local window only; it never loads anything from the internet as a page).
const { app, BrowserWindow, shell, Menu, session } = require('electron');
const path = require('path');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

function createWindow() {
  const win = new BrowserWindow({
    width: 1360,
    height: 840,
    minWidth: 900,
    minHeight: 560,
    backgroundColor: '#0d1520',
    title: 'Northline TV',
    icon: path.join(__dirname, 'build', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false,
      allowRunningInsecureContent: true,
      backgroundThrottling: false,
      additionalArguments: ['--nl-version=' + app.getVersion()],
    },
  });
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  // the window only ever shows Northline: links open in your normal browser
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://')) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); }
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

// Talk to TV services exactly like the Fire Stick app does. Some servers (Alley Cat World) turn away anything
// that looks like a web browser, answering 513, so send the Fire Stick app's name and drop the browser-only headers.
const TV_UA = 'NorthlineTV/1.0 (Android TV)';
const BROWSER_ONLY = /^(origin|referer|sec-ch-ua.*|sec-fetch-.*|accept-language)$/i;

app.whenReady().then(() => {
  session.defaultSession.webRequest.onBeforeSendHeaders({ urls: ['http://*/*', 'https://*/*'] }, (d, done) => {
    let host = '';
    try { host = new URL(d.url).hostname; } catch (e) {}
    if (/(^|\.)github(usercontent)?\.com$/i.test(host) || /(^|\.)githubusercontent\.com$/i.test(host)) return done({ requestHeaders: d.requestHeaders });
    const h = {};
    for (const k of Object.keys(d.requestHeaders)) if (!BROWSER_ONLY.test(k)) h[k] = d.requestHeaders[k];
    h['User-Agent'] = TV_UA;
    done({ requestHeaders: h });
  });
  if (process.platform === 'darwin') {
    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { role: 'appMenu' }, { role: 'editMenu' }, { role: 'viewMenu' }, { role: 'windowMenu' },
    ]));
  } else {
    Menu.setApplicationMenu(null);
  }
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
