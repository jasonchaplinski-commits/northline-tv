// Northline TV for Windows and Mac: one window running the app in app/.
// The page talks to your TV service directly (IPTV servers don't allow browser pages, so web security is off
// for this local window only; it never loads anything from the internet as a page).
const { app, BrowserWindow, shell, Menu, session, ipcMain, net, dialog, powerSaveBlocker } = require('electron');
const path = require('path');
const fs = require('fs');
const guide = require('./guide');
const { Recorder } = require('./recorder');

app.commandLine.appendSwitch('autoplay-policy', 'no-user-gesture-required');

let win = null;
function createWindow() {
  win = new BrowserWindow({
    width: 1360,
    height: 840,
    minWidth: 900,
    minHeight: 560,
    backgroundColor: '#0d1520',
    title: 'Northline TV',
    icon: path.join(__dirname, 'build', 'icon.png'),
    autoHideMenuBar: true,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false,
      allowRunningInsecureContent: true,
      backgroundThrottling: false,
      additionalArguments: ['--nl-version=' + app.getVersion()],
    },
  });
  win.loadFile(path.join(__dirname, 'app', 'index.html'));
  // the window only ever shows Northline: links open in your normal browser
  win.webContents.on('will-navigate', (e, url) => {
    if (!url.startsWith('file://')) { e.preventDefault(); if (/^https?:/.test(url)) shell.openExternal(url); }
  });
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
}

// Talk to TV services exactly like the Fire Stick app does. Some servers (Alley Cat World) turn away anything
// that looks like a web browser, answering 513, so send the Fire Stick app's name and drop the browser-only headers.
const TV_UA = 'NorthlineTV/1.0 (Android TV)';
const BROWSER_ONLY = /^(origin|referer|sec-ch-ua.*|sec-fetch-.*|accept-language)$/i;

app.whenReady().then(() => {
  session.defaultSession.webRequest.onBeforeSendHeaders({ urls: ['http://*/*', 'https://*/*'] }, (d, done) => {
    let host = '';
    try { host = new URL(d.url).hostname; } catch (e) {}
    if (/(^|\.)github(usercontent)?\.com$/i.test(host) || /(^|\.)githubusercontent\.com$/i.test(host)) return done({ requestHeaders: d.requestHeaders });
    const h = {};
    for (const k of Object.keys(d.requestHeaders)) if (!BROWSER_ONLY.test(k)) h[k] = d.requestHeaders[k];
    h['User-Agent'] = TV_UA;
    done({ requestHeaders: h });
  });
  if (process.platform === 'darwin') {
    Menu.setApplicationMenu(Menu.buildFromTemplate([
      { role: 'appMenu' }, { role: 'editMenu' }, { role: 'viewMenu' }, { role: 'windowMenu' },
    ]));
  } else {
    Menu.setApplicationMenu(null);
  }
  createWindow();
  app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
});

// ---------------- the guide in one download ----------------
const guideCache = new Map(); // service key → { at, data }
ipcMain.handle('guide', async (_e, { base, user, pass, ids, force }) => {
  const key = base.toLowerCase() + '|' + user + '|' + (ids ? ids.length + ':' + String(ids[0] || '') : 'all');
  const c = guideCache.get(key);
  if (c && !force && Date.now() - c.at < 4 * 3600e3) return c.data;
  const data = await guide.download(net.fetch, base, user, pass, ids, { ua: TV_UA });
  guideCache.set(key, { at: Date.now(), data });
  return data;
});

// the free backup guide (or your own link): fills channels your provider leaves empty, matched by channel name
const backupCache = new Map();
ipcMain.handle('backupGuide', async (_e, { url, keys, force }) => {
  const key = url + '|' + keys.length + ':' + (keys[0] || '');
  const c = backupCache.get(key);
  if (c && !force && Date.now() - c.at < 6 * 3600e3) return c.data;
  const data = await guide.downloadByName(net.fetch, url, keys, { ua: 'Mozilla/5.0 NorthlineTV' });
  backupCache.clear(); // keep only the newest one: these can be big
  backupCache.set(key, { at: Date.now(), data });
  return data;
});

// ---------------- recording ----------------
let sleepBlock = -1;
const rec = new Recorder(net.fetch, () => {
  const busy = rec.jobs.size > 0;
  if (busy && sleepBlock < 0) sleepBlock = powerSaveBlocker.start('prevent-app-suspension');
  if (!busy && sleepBlock >= 0) { powerSaveBlocker.stop(sleepBlock); sleepBlock = -1; }
  if (win && !win.isDestroyed()) win.webContents.send('rec:changed', rec.list());
}, { ua: TV_UA });
const defaultFolder = () => path.join(app.getPath('videos'), 'Northline TV Recordings');
ipcMain.handle('rec:start', (_e, job) => rec.start({ ...job, dir: job.dir || defaultFolder() }));
ipcMain.handle('rec:stop', (_e, id) => rec.stop(id));
ipcMain.handle('rec:list', () => rec.list());
ipcMain.handle('rec:defaultFolder', () => defaultFolder());
ipcMain.handle('rec:chooseFolder', async (_e, current) => {
  const r = await dialog.showOpenDialog(win, { title: 'Where should recordings go?', defaultPath: current || defaultFolder(), properties: ['openDirectory', 'createDirectory'] });
  return r.canceled || !r.filePaths.length ? null : r.filePaths[0];
});
ipcMain.handle('rec:openFolder', async (_e, dir) => { const d = dir || defaultFolder(); fs.mkdirSync(d, { recursive: true }); return shell.openPath(d); });
ipcMain.handle('rec:showFile', (_e, file) => { if (file && fs.existsSync(file)) shell.showItemInFolder(file); });
ipcMain.handle('rec:freeSpace', async (_e, dir) => {
  try { let d = dir || defaultFolder(); while (!fs.existsSync(d)) d = path.dirname(d); const s = await fs.promises.statfs(d); return s.bavail * s.bsize; } catch (_) { return -1; }
});
// closing the window while recording: ask first
app.on('browser-window-created', (_e, w) => w.on('close', (ev) => {
  if (!rec.jobs.size) return;
  const n = dialog.showMessageBoxSync(w, { type: 'warning', buttons: ['Keep recording', 'Stop and quit'], defaultId: 0, cancelId: 0, message: 'Northline TV is recording', detail: 'Closing stops the recording. Minimize the window instead to keep recording.' });
  if (n === 0) ev.preventDefault(); else rec.stopAll();
}));

app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
