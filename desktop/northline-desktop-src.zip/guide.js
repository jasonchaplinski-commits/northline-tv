// The TV guide in one download (xmltv.php), like the Fire Stick app, instead of asking the server channel by channel.
// Read as it streams in, so even a big guide file never sits in memory whole; only the next day or so is kept.
'use strict';

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
function unxml(s) {
  return String(s || '')
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => e[0] === '#' ? String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : +e.slice(1)) : (ENT[e] != null ? ENT[e] : m))
    .trim();
}

/** "20261125200000 +0000" (or without the zone) → ms since 1970. 0 if unreadable. */
function xmltvTime(t) {
  const m = /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?\s*([+-]\d{4})?/.exec(String(t || '').trim());
  if (!m) return 0;
  let ms = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
  if (m[7]) { const sign = m[7][0] === '-' ? -1 : 1; ms -= sign * (+m[7].slice(1, 3) * 60 + +m[7].slice(3, 5)) * 60000; }
  return ms;
}

const attr = (tag, name) => { const m = new RegExp('\\s' + name + '\\s*=\\s*"([^"]*)"', 'i').exec(tag) || new RegExp('\\s' + name + "\\s*=\\s*'([^']*)'", 'i').exec(tag); return m ? m[1] : ''; };

/**
 * A parser you feed text pieces to. Keeps programmes for the [wanted] channel ids (lower case) between [from] and [to].
 * result(): { channelId: [{start, stop, title, desc}] } sorted by start.
 */
function makeParser(wanted, from, to) {
  const out = Object.create(null);
  let buf = '';
  function take(block) {
    const open = /^<programme\b[^>]*>/i.exec(block); if (!open) return;
    const ch = unxml(attr(open[0], 'channel')).toLowerCase();
    if (wanted && !wanted.has(ch)) return;
    const start = xmltvTime(attr(open[0], 'start')), stop = xmltvTime(attr(open[0], 'stop'));
    if (!start || !stop || stop <= from || start >= to) return;
    const title = /<title\b[^>]*>([\s\S]*?)<\/title>/i.exec(block);
    const desc = /<desc\b[^>]*>([\s\S]*?)<\/desc>/i.exec(block);
    (out[ch] || (out[ch] = [])).push({ start, stop, title: unxml(title && title[1]) || 'No title', desc: unxml(desc && desc[1]).replace(/<[^>]+>/g, '').slice(0, 600) });
  }
  return {
    feed(text) {
      buf += text;
      let i;
      for (;;) {
        const a = buf.search(/<programme\b/i); if (a < 0) { buf = buf.slice(-20); break; }
        i = buf.indexOf('</programme>', a); if (i < 0) { buf = buf.slice(a); break; }
        take(buf.slice(a, i)); buf = buf.slice(i + 12);
      }
    },
    result() {
      for (const k of Object.keys(out)) {
        const seen = new Set();
        out[k] = out[k].sort((x, y) => x.start - y.start).filter((e) => !seen.has(e.start) && seen.add(e.start));
      }
      return out;
    },
  };
}

/** Downloads and reads the guide with [fetchFn] (Electron's net.fetch). */
async function download(fetchFn, base, user, pass, wantedIds, opts = {}) {
  const now = Date.now();
  const p = makeParser(wantedIds ? new Set(wantedIds.map((x) => String(x).toLowerCase())) : null, now - 3 * 3600e3, now + (opts.hours || 30) * 3600e3);
  const url = `${base}/xmltv.php?username=${encodeURIComponent(user)}&password=${encodeURIComponent(pass)}`;
  const r = await fetchFn(url, { headers: { 'User-Agent': opts.ua || 'NorthlineTV/1.0 (Android TV)' } });
  if (!r.ok) throw new Error('The guide answered ' + r.status);
  const dec = new TextDecoder();
  if (r.body && r.body.getReader) {
    const rd = r.body.getReader();
    for (;;) { const { done, value } = await rd.read(); if (done) break; p.feed(dec.decode(value, { stream: true })); }
  } else p.feed(await r.text());
  p.feed(dec.decode());
  return p.result();
}

module.exports = { makeParser, xmltvTime, unxml, download };
