// The TV guide in one download (xmltv.php), like the Fire Stick app, instead of asking the server channel by channel.
// Read as it streams in, so even a big guide file never sits in memory whole; only the next day or so is kept.
'use strict';

const ENT = { amp: '&', lt: '<', gt: '>', quot: '"', apos: "'" };
function unxml(s) {
  return String(s || '')
    .replace(/<!\[CDATA\[([\s\S]*?)\]\]>/g, '$1')
    .replace(/&(#x[0-9a-f]+|#\d+|\w+);/gi, (m, e) => e[0] === '#' ? String.fromCodePoint(e[1] === 'x' || e[1] === 'X' ? parseInt(e.slice(2), 16) : +e.slice(1)) : (ENT[e] != null ? ENT[e] : m))
    .trim();
}

/** "20261125200000 +0000" (or without the zone) → ms since 1970. 0 if unreadable. */
function xmltvTime(t) {
  const m = /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?\s*([+-]\d{4})?/.exec(String(t || '').trim());
  if (!m) return 0;
  let ms = Date.UTC(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +(m[6] || 0));
  if (m[7]) { const sign = m[7][0] === '-' ? -1 : 1; ms -= sign * (+m[7].slice(1, 3) * 60 + +m[7].slice(3, 5)) * 60000; }
  return ms;
}

const attr = (tag, name) => { const m = new RegExp('\\s' + name + '\\s*=\\s*"([^"]*)"', 'i').exec(tag) || new RegExp('\\s' + name + "\\s*=\\s*'([^']*)'", 'i').exec(tag); return m ? m[1] : ''; };

/**
 * A parser you feed text pieces to. Keeps programmes for the [wanted] channel ids (lower case) between [from] and [to].
 * result(): { channelId: [{start, stop, title, desc}] } sorted by start.
 */
function makeParser(wanted, from, to) {
  const out = Object.create(null);
  let buf = '';
  function take(block) {
    const open = /^<programme\b[^>]*>/i.exec(block); if (!open) return;
    const ch = unxml(attr(open[0], 'channel')).toLowerCase();
    if (wanted && !wanted.has(ch)) return;
    const start = xmltvTime(attr(open[0], 'start')), stop = xmltvTime(attr(open[0], 'stop'));
    if (!start || !stop || stop <= from || start >= to) return;
    const title = /<title\b[^>]*>([\s\S]*?)<\/title>/i.exec(block);
    const desc = /<desc\b[^>]*>([\s\S]*?)<\/desc>/i.exec(block);
    (out[ch] || (out[ch] = [])).push({ start, stop, title: unxml(title && title[1]) || 'No title', desc: unxml(desc && desc[1]).replace(/<[^>]+>/g, '').slice(0, 600) });
  }
  return {
    feed(text) {
      buf += text;
      let i;
      for (;;) {
        const a = buf.search(/<programme\b/i); if (a < 0) { buf = buf.slice(-20); break; }
        i = buf.indexOf('</programme>', a); if (i < 0) { buf = buf.slice(a); break; }
        take(buf.slice(a, i)); buf = buf.slice(i + 12);
      }
    },
    result() {
      for (const k of Object.keys(out)) {
        const seen = new Set();
        out[k] = out[k].sort((x, y) => x.start - y.start).filter((e) => !seen.has(e.start) && seen.add(e.start));
      }
      return out;
    },
  };
}

/** Reads [url] as text, piece by piece, unpacking .gz files (the free guides come packed). */
async function streamText(fetchFn, url, ua, onText) {
  const r = await fetchFn(url, { headers: { 'User-Agent': ua || 'NorthlineTV/1.0 (Android TV)' } });
  if (!r.ok) throw new Error('The guide answered ' + r.status);
  const dec = new TextDecoder();
  if (!r.body || !r.body.getReader) { onText(await r.text()); return; }
  let rd = r.body.getReader();
  let first = await rd.read();
  if (!first.done && first.value && first.value[0] === 0x1f && first.value[1] === 0x8b) {
    // gzip: put the first piece back and unpack the whole stream
    const head = first.value, rest = rd;
    const src = new ReadableStream({
      start(c) { c.enqueue(head); },
      async pull(c) { const x = await rest.read(); if (x.done) c.close(); else c.enqueue(x.value); },
      cancel() { rest.cancel(); },
    });
    rd = src.pipeThrough(new DecompressionStream('gzip')).getReader();
    first = await rd.read();
  }
  for (let x = first; !x.done; x = await rd.read()) onText(dec.decode(x.value, { stream: true }));
  onText(dec.decode());
}

/** Downloads and reads your provider's guide with [fetchFn] (Electron's net.fetch). */
async function download(fetchFn, base, user, pass, wantedIds, opts = {}) {
  const now = Date.now();
  const p = makeParser(wantedIds ? new Set(wantedIds.map((x) => String(x).toLowerCase())) : null, now - 3 * 3600e3, now + (opts.hours || 30) * 3600e3);
  await streamText(fetchFn, `${base}/xmltv.php?username=${encodeURIComponent(user)}&password=${encodeURIComponent(pass)}`, opts.ua, (t) => p.feed(t));
  return p.result();
}

/**
 * A guide from any link (the free backup guide), matched by channel name instead of id: only the channels whose
 * names fit [wantedKeys] (from Names.keysFor) are kept. Returns { index: key → guide channel id, data: id → shows }.
 */
async function downloadByName(fetchFn, url, wantedKeys, opts = {}) {
  const Names = require('./app/chkey.js');
  const want = new Set(wantedKeys);
  const now = Date.now(), from = now - 3 * 3600e3, to = now + (opts.hours || 30) * 3600e3;
  const index = Object.create(null);
  const ids = new Set();
  const p = makeParser(ids, from, to);
  let buf = '';
  await streamText(fetchFn, url, opts.ua, (t) => {
    // the <channel> list comes first: it says which ids are which channels
    buf += t;
    for (;;) {
      const a = buf.search(/<channel\b/i);
      const pr = buf.search(/<programme\b/i);
      if (a < 0 || (pr >= 0 && pr < a)) break;
      const e = buf.indexOf('</channel>', a); if (e < 0) break;
      const block = buf.slice(a, e);
      const id = unxml(attr(/^<channel\b[^>]*>/i.exec(block)[0], 'id'));
      const names = [...block.matchAll(/<display-name\b[^>]*>([\s\S]*?)<\/display-name>/gi)].map((m) => unxml(m[1]));
      for (const n of names) for (const k of Names.guideKeys(n)) if (want.has(k) && !(k in index)) { index[k] = id.toLowerCase(); ids.add(id.toLowerCase()); }
      buf = buf.slice(0, a) + buf.slice(e + 10);
    }
    if (/<programme\b/i.test(buf)) { p.feed(buf); buf = ''; }
  });
  p.feed(buf);
  return { index, data: p.result() };
}

module.exports = { makeParser, xmltvTime, unxml, download, downloadByName, streamText };
