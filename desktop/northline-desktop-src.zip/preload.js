const { contextBridge, shell } = require('electron');
const pkg = require('./package.json');

contextBridge.exposeInMainWorld('northline', {
  version: pkg.version,
  platform: process.platform,
  openLink: (url) => { if (/^https:\/\//.test(url)) shell.openExternal(url); },
});
