// sandboxed preload: only electron's own modules work here, so the version comes in from main.js
const { contextBridge, shell, ipcRenderer } = require('electron');
const arg = (process.argv || []).find((a) => a.startsWith('--nl-version='));

contextBridge.exposeInMainWorld('northline', {
  version: arg ? arg.slice('--nl-version='.length) : '',
  platform: process.platform,
  openLink: (url) => { if (/^https:\/\//.test(url)) shell.openExternal(url); },
  guide: (q) => ipcRenderer.invoke('guide', q),
  backupGuide: (q) => ipcRenderer.invoke('backupGuide', q),
  rec: {
    start: (job) => ipcRenderer.invoke('rec:start', job),
    stop: (id) => ipcRenderer.invoke('rec:stop', id),
    list: () => ipcRenderer.invoke('rec:list'),
    defaultFolder: () => ipcRenderer.invoke('rec:defaultFolder'),
    chooseFolder: (cur) => ipcRenderer.invoke('rec:chooseFolder', cur),
    openFolder: (dir) => ipcRenderer.invoke('rec:openFolder', dir),
    showFile: (f) => ipcRenderer.invoke('rec:showFile', f),
    freeSpace: (dir) => ipcRenderer.invoke('rec:freeSpace', dir),
    onChange: (f) => ipcRenderer.on('rec:changed', (_e, list) => f(list)),
  },
});
