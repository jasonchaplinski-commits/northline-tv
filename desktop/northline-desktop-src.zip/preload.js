// sandboxed preload: only electron's own modules work here, so the version comes in from main.js
const { contextBridge, shell } = require('electron');
const arg = (process.argv || []).find((a) => a.startsWith('--nl-version='));

contextBridge.exposeInMainWorld('northline', {
  version: arg ? arg.slice('--nl-version='.length) : '',
  platform: process.platform,
  openLink: (url) => { if (/^https:\/\//.test(url)) shell.openExternal(url); },
});
